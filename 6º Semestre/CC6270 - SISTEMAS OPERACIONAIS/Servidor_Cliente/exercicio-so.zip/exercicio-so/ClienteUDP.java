import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Scanner;

public class ClienteUDP {
  public static void main(String[] args) {
    System.out.println("Cliente UDP");
    DatagramSocket socket = null;

    Scanner s = new Scanner(System.in);
    System.out.println("Escolha uma opção:\n1 - soma\n2 - multiplicação\n3 - divisão\n4 - subtração\n5 - potência");
    String operacao = s.nextLine();
    System.out.println("Entre o 1º número: ");
    String num1 = s.nextLine();
    System.out.println("Entre o 2º número: ");
    String num2 = s.nextLine();

    String mensagem = "";

    switch (operacao) {
      case "1":
        mensagem = "soma";
        break;
      case "2":
        mensagem = "multiplicacao";
        break;
      case "3":
        mensagem = "divisao";
        break;
      case "4":
        mensagem = "subtracao";
        break;
      case "5":
        mensagem = "potencia";
        break;
    }

    mensagem += ":" + num1 + ":" + num2 + ":";

    byte[] m = mensagem.getBytes();
    int tamanho = mensagem.length();
    try {
      InetAddress endereco =
              InetAddress.getByName("localhost");
      int porta = 7890;

      DatagramPacket pacoteMensagem =
              new DatagramPacket(m, tamanho, endereco, porta);
      socket = new DatagramSocket();
      socket.send(pacoteMensagem);
      byte[] buffer = new byte[1000];

      DatagramPacket resposta =
              new DatagramPacket(buffer, buffer.length);
      socket.receive(resposta);

      System.out.println("resposta do servidor: "
              + new String(resposta.getData()));

    } catch (SocketException e) {
      System.out.println("Socket: " + e.getMessage());
    } catch (IOException e) {
      System.out.println("IO: " + e.getMessage());
    } finally {
      if (socket != null) {
        socket.close();
      }
    }
  }
}
