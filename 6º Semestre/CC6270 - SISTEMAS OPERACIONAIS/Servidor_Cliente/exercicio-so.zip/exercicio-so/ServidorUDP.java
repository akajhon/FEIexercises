import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
public class ServidorUDP {
  public static void main(String[] args) {
    System.out.println("Servidor UDP online");
    DatagramSocket socket = null;
    try {
      socket = new DatagramSocket(7890);
      byte[] buffer = new byte[1000];
      while (true) {
      DatagramPacket requisicao =
      new DatagramPacket(buffer, buffer.length);

      socket.receive(requisicao);
      System.out.println("Recebi requisicao: "
      + requisicao.getAddress().toString());

      String mensagemDoCliente = new String(requisicao.getData());
      System.out.println("Mensagem do cliente: " + mensagemDoCliente);
      String array[] = new String[3];

      array = mensagemDoCliente.split(":");
      String operacao = array[0];
      int num1 = Integer.parseInt(array[1]);
      int num2 = Integer.parseInt(array[2]);

      int resultado = 0;

      switch (operacao) {
        case "soma":
          resultado = num1 + num2;
          break;
        case "multiplicacao":
          resultado = num1 * num2;
          break;
        case "divisao":
          resultado = num1 / num2;
          break;
        case "subtracao":
          resultado = num1 - num2;
          break;
        case "potencia":
          resultado = num1 ^ num2;
          break;
      }

      DatagramPacket resposta = new DatagramPacket(
      Integer.toString(resultado).getBytes(),
      Integer.toString(resultado).getBytes().length,
      requisicao.getAddress(),
      requisicao.getPort());
      socket.send(resposta);
      System.out.println("Resposta enviada para: "
      + requisicao.getAddress().toString() + "\n");
    }

    }catch (SocketException e) {
      System.out.println("Socket: " + e.getMessage());
    }catch (IOException e) {
      System.out.println("IO: " + e.getMessage());
    }
  }
}
