#!/bin/bash

touch main.py
echo "print(\"Hello World (feito pelo filho)\")" >> main.py
