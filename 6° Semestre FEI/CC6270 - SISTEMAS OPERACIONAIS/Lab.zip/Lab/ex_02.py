import os
import sys
from datetime import datetime
from pwd import getpwuid

def walk():
    search_dirs = sys.argv
    search_dirs.pop(0)
    if len(search_dirs) == 0:
        search_dirs.append(".")


    for search_dir in search_dirs:
        os.path.join(search_dir)
        directory = os.listdir(search_dir)
        for item in directory:
            place = os.stat(search_dir + "/" + item)
            author = getpwuid(place.st_uid).pw_name
            creation = datetime.fromtimestamp(place.st_ctime).strftime("%d/%m/%Y -> %H:%M:%S")
            modification = datetime.fromtimestamp(place.st_mtime).strftime("%d/%m/%Y -> %H:%M:%S")
            print("**************")
            print(f"{item}")
            print(f"Author: {author}")
            print(f"Size: {place.st_size} bytes")
            print(f"Creation Date: {creation}")
            print(f"Modification Date: {modification}")

if __name__ == '__main__':
    walk()