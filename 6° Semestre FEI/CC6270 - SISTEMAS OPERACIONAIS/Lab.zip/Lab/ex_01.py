import os

def walk(init_dir):
    sizes = {}
    for root, dirs, files in os.walk(init_dir, topdown=True):
        for name in files:
            file_size = os.stat(root + "/" + name).st_size
            sizes[name] = file_size
    ordered_sizes = dict(sorted(sizes.items(), key=lambda file: file[1], reverse=True))
    for archive in ordered_sizes.items():
        print(f"[*] {archive[0]} -> {archive[1]}b")

if __name__ == '__main__':
    init_dir = input("[+] Entre com o diretório em que deseja começar: ")
    walk(init_dir)