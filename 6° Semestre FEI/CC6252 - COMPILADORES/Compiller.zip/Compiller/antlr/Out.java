import java.util.Scanner;

public class Out {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("OI");
        String x=entrada.nextLine();
        System.out.println("TESTE");
        int real=10;
        if(5==5) {
            int realy=10;
        }
        else {
            int realx=7;
        }
        while (real!=6) {
            real=real+1;
        }
        do {
            real=real+1;
        }
        while (real<10);
        System.out.println(x);

    }
}
