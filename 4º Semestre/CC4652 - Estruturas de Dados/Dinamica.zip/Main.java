import java.util.Scanner;

interface IFila {
    boolean insere(int i);
    
    void imprime();
}

class Heap implements IFila {
    public int[] v;
    public int n;
  
    public Heap(int[] vinicial, int tamMax) {
        v = new int[tamMax];
        n = vinicial.length;
        System.arraycopy(vinicial, 0, v, 0, vinicial.length);
        for (int i = ultimoPai(); i >= 0; i--) {
            sift(i);
        }
    }

    public Heap(int tamMax) {
        v = new int[tamMax];
        n = 0;
    }

    private int fe(int idx) {
        return 2 * idx + 1;
    }

    private int fd(int idx) {
        return 2 * idx + 2;
    }

    private int pai(int idx) {
        return (idx - 1) / 2;
    }

    private int ultimoPai() {
        return pai(n - 1);
    }

    private void sift(int idx) {
        if (idx > ultimoPai() || n == 1) {
            return;
        }

        int idxMaiorFilho = fe(idx);
        if (fd(idx) < n && v[fd(idx)] > v[idxMaiorFilho])
            idxMaiorFilho = fd(idx);

        if (v[idxMaiorFilho] > v[idx]) {
            int temp = v[idxMaiorFilho];
            v[idxMaiorFilho] = v[idx];
            v[idx] = temp;
            sift(idxMaiorFilho);
        }
    }

    @Override
    public boolean insere(int i) {
        v[n] = i;
        n++;
        for (int j=ultimoPai();j > 0; j = pai(j)){
          sift(j);      
        }
        sift(0);
        return true;
    }


    @Override
    public void imprime() {
        for (int i = 0; i < n; i++) {
            System.out.print(v[i] + " ");
        }
        System.out.println("");
    }
    
    public void ordena(int[] v){
      int k=0;
      n = v.length;
    
      for(k = n / 2 - 1; k >= 0; k--){
        ordenaHeap(v ,n, k);
      }

      for (k = n - 1; k > 0; k--) {
        int tmp = v[0];
        v[0] = v[k];
        v[k] = tmp;

        ordenaHeap(v, k, 0);
      }
    
    }

    private void ordenaHeap(int[] v, int n, int k){
      int maior = k;
      int dir = 2 * k + 2;
      int esq = 2 * k + 1;

      if ( v[esq] > v[maior] && esq < n )
        maior = esq;

      if (v[dir] > v[maior] && dir < n)
        maior = dir;

      if (maior != k) {
        int tmp = v[k];
        v[k] = v[maior];
        v[maior] = tmp;
        ordenaHeap(v, n, maior);
    }
    }


  
}


public class Main {
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in); 
      int op = 3;
      System.out.println("Digite o tamanho do vetor:");
      int n = input.nextInt(); 
      int v[] = new int[n];
      for(int i = 0; i < n; i++){
        System.out.println("Digite os valores:");
        v[i]= input.nextInt();
      }
      
      Heap h = new Heap(v, n);

        do{
          System.out.println("************* MAX HEAP *************");;
          System.out.println(" 1 - Ordenar como Máx Heap");
          System.out.println(" 2 - Ordernar como Crescente e Sair");
          System.out.println("************************************");
          System.out.println("Digite a opção: ");
          op = input.nextInt();
          if(op == 1){
            System.out.println("Heap:");
            h.imprime();
            
          }
          else if(op == 2){
            System.out.println("Ordem Crescente:");
            h.ordena(h.v);
            h.imprime();
            System.out.println("Finalizado!!!");
            op = 5;
          }

          
        }while(op >= 1 && op <= 2);

    }
}