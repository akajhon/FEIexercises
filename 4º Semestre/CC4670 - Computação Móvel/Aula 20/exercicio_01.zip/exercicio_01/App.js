import React from "react";
import { Text, View, Button, TextInput, StyleSheet } from "react-native";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: undefined,
      user: undefined,
      age: undefined,
      email: undefined,
      tel: undefined,
      senha: undefined,
    };
  }

  cadastra() {
    alert("[+] Dados Cadastrados [+]\n\n" + "[=] Nome = " + this.state.name + "\n[=] Usuário = " + this.state.user + "\n[=] Idade = " + this.state.age + "\n[=] E-mail = " + this.state.email + "\n[=] Telefone = " + this.state.tel + "\n[=] Senha = " + this.state.senha);
  }

  render() {
    return (
      <View>
        <Text style={estilos.texto}>{"[*] Entre com seus dados [*]"}</Text>
        <Text>{"\n"}</Text>
        <Text style={estilos.texto}>{"[+] Nome: "}</Text>
        <TextInput
          onChangeText={(texto) => this.setState({ name: texto })}
          style={estilos.caixa}
        ></TextInput>
        <Text>{'\n'}</Text>
        <Text style={estilos.texto}>{"[+] Usuário: "}</Text>
        <TextInput
          onChangeText={(texto) => this.setState({ user: texto })}
          style={estilos.caixa}
        ></TextInput>
        <Text>{'\n'}</Text>
        <Text style={estilos.texto}>{"[+] Idade: "}</Text>
        <TextInput
          onChangeText={(texto) => this.setState({ age: texto })}
          style={estilos.caixa}
        ></TextInput>
        <Text>{'\n'}</Text>
        <Text style={estilos.texto}>{"[+] E-mail: "}</Text>
        <TextInput
          onChangeText={(texto) => this.setState({ email: texto })}
          style={estilos.caixa}
        ></TextInput>
        <Text>{'\n'}</Text>
        <Text style={estilos.texto}>{"[+] Telefone: "}</Text>
        <TextInput
          onChangeText={(texto) => this.setState({ tel: texto })}
          style={estilos.caixa}
        ></TextInput>
        <Text>{'\n'}</Text>
        <Text style={estilos.texto}>{"[+] Senha: "}</Text>
        <TextInput
          onChangeText={(texto) => this.setState({ senha: texto })}
          secureTextEntry={true}
          style={estilos.caixa}
        ></TextInput>
        <Text>{'\n'}</Text>
        <Button title="Cadastrar" onPress={this.cadastra.bind(this)}></Button>
      </View>
    );
  }
}

const estilos = StyleSheet.create({
  texto: {
    fontSize: 20,
  },
  caixa: {
    fontSize: 15,
    borderColor: "orange",
    borderWidth: 3,
  },
});

export default App;