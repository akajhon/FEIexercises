import Firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyCfB6WPxTke74xj375-1kNf6fu20j_gG38",
  authDomain: "myrecipe-cc4670.firebaseapp.com",
  databaseURL: "https://myrecipe-cc4670-default-rtdb.firebaseio.com",
  projectId: "myrecipe-cc4670",
  storageBucket: "myrecipe-cc4670.appspot.com",
  messagingSenderId: "95481276414",
  appId: "1:95481276414:web:14c0bd51ddbe5cdcf3c2af"
};

const fire = Firebase.initializeApp(firebaseConfig);
export const db = fire.database();