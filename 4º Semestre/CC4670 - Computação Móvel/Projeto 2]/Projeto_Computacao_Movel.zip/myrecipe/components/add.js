import React from 'react';
import { View, Text, Button, TextInput, FlatList, TouchableOpacity, ScrollView } from 'react-native';
import estilos from '../estilos';
import { db } from '../Config';

export class Add extends React.Component {
  constructor(props) {
    super(props);
    this.nome = '';
    this.ingredientes = '';
    this.preparo = ''
  }

  gravar() {
    db.ref('/receitas').push({
      nome: this.state.nome,
      ingredientes: this.state.ingredientes,
      preparo: this.state.preparo
    })
    alert("Receita Registrada!")
  }

  render() {
    return (
      <View style={estilos.Body}>
      <ScrollView>
        <View style={estilos.Container}>
          <Text style={estilos.Text}>Nome da Receita: </Text>
          
          <TextInput
            style={estilos.Input}
            onChangeText={(texto) => this.setState({nome: texto})}></TextInput>

          <Text style={estilos.Text}>Ingredientes: </Text>

          <TextInput
            multiline={true}
            numberOfLines={10}
            style={estilos.InputTextArea}
            onChangeText={(texto) => this.setState({ingredientes: texto})}></TextInput>

          <Text style={estilos.Text}>Modo de preparo:</Text>

          <TextInput
            multiline={true}
            numberOfLines={10}
            style={estilos.InputTextArea}
            onChangeText={(texto) => this.setState({preparo: texto})}></TextInput>
            
          <TouchableOpacity style={estilos.Button} onPress={() => this.gravar()}> <Text style={estilos.ButtonText}> Salvar esta receita </Text> </TouchableOpacity>
        </View>
        </ScrollView>
      </View>
    );
  }
}