import React from 'react';
import {Audio} from 'expo-av';
import { View, Text, Button, TextInput, FlatList, TouchableOpacity, ScrollView, Animated } from 'react-native';
import estilos from '../estilos';
import { db } from '../Config';

export class Timer extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      timer: null,
      minutes_Counter: '00',
      seconds_Counter: '00',
      startDisable: false,
      op :new Animated.Value(0)
    }
    this.som = new Audio.Sound();
    this.som.loadAsync(require('../assets/timer.wav'));
  }

  componentWillUnmount() {
    clearInterval(this.state.timer);
  }

  tocar(){
    this.som.setPositionAsync(0);
    this.som.playAsync();
    this.som.setOnPlaybackStatusUpdate( (estado) => {
      if(estado.didJustFinish == true){
        this.som.setPositionAsync(0);
        this.som.playAsync();
      }
    } )
  }

  onButtonStart = () => {

    this.som.stopAsync();

    let timer = setInterval(() => {
 
      var num = (Number(this.state.seconds_Counter) - 1).toString(),
        count = this.state.minutes_Counter;

      if (Number(this.state.minutes_Counter) == 0 && Number(this.state.seconds_Counter) == 1) {
        this.tocar();
        clearInterval(this.state.timer);
        this.setState({startDisable : false})
        this.animation();
      }

      if (Number(this.state.seconds_Counter) == 0 ) {
        count = (Number(this.state.minutes_Counter) - 1).toString();
        num = '59';
      }
 
      this.setState({
        minutes_Counter: count.length == 1 ? '0' + count : count,
        seconds_Counter: num.length == 1 ? '0' + num : num
      });
    }, 1000);
    this.setState({ timer });
 
    this.setState({startDisable : true})
  }

  onButtonStop = () => {
    this.som.stopAsync();
    clearInterval(this.state.timer);
    this.setState({startDisable : false})
    Animated.timing(this.state.op, {
        duration: 2000,
        toValue: 0,
      }).start();
  }

  onButtonClear = () => {
    this.som.stopAsync();
    this.setState({
      timer: null,
      minutes_Counter: '00',
      seconds_Counter: '00',
    });
    Animated.timing(this.state.op, {
        duration: 2000,
        toValue: 0,
      }).start();
  }

  animation() {
    Animated.loop(
    Animated.timing(this.state.op, {
        duration: 3000,
        toValue: 1,
      }),
    Animated.timing(this.state.op, {
        duration: 3000,
        toValue: 0,
      })
    ).start();
  }

 render() {
    return (
    <View style={estilos.Body}>
    <ScrollView>
     <View style={estilos.Container}>

        <View style={estilos.TimerContainer}>

        <Animated.Text style={{opacity: this.state.op, fontSize: 50,fontWeight: 'bold', color:'tomato'}}> Acabou!!! </Animated.Text>

        <Text style={estilos.Timer}>{this.state.minutes_Counter}:{this.state.seconds_Counter}</Text>

          <Text style={estilos.Text}>Tempo em Minutos: </Text>
          <TextInput
            style={estilos.Input}
            onChangeText={(texto) => this.setState({minutes_Counter: texto}) }>
          </TextInput>

        <TouchableOpacity
          onPress={this.onButtonStart}
          activeOpacity={0.6}
          style={[estilos.Button, { backgroundColor: this.state.startDisable ? '#B0BEC5' : 'tomato' }]} 
          disabled={this.state.startDisable} >
 
          <Text style={estilos.Text}> Iniciar </Text>
 
        </TouchableOpacity>
 
        <TouchableOpacity
          onPress={this.onButtonStop}
          activeOpacity={0.6}
          style={[estilos.Button, { backgroundColor:  'tomato'}]} >
 
          <Text style={estilos.Text}> Parar </Text>
 
        </TouchableOpacity>
 
        <TouchableOpacity
          onPress={this.onButtonClear}
          activeOpacity={0.6}
          style={[estilos.Button, { backgroundColor: this.state.startDisable ? '#B0BEC5' : 'tomato' }]} 
          disabled={this.state.startDisable} >
 
          <Text style={estilos.Text}> Zerar </Text>
 
        </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
    </View>
    );
  }
}