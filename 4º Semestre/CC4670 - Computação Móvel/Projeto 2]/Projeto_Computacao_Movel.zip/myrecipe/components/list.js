import React from 'react';
import { View, Text, Button, TextInput, FlatList, TouchableOpacity, ScrollView } from 'react-native';
import estilos from '../estilos';
import { db } from '../Config';

export class List extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      receitas: []
    }
  }

  componentDidMount(){
    db.ref('/receitas').on('value', snapshot => {
      let data = snapshot.val();
      let dados = Object.values(data);
      this.setState({receitas: dados});
    })
  }

  render() {
    return (
      <ScrollView>
      <View style={estilos.Container}>
      
      <FlatList
        data = {this.state.receitas}
        renderItem = {({item}) =>
          <View style={estilos.SubContainer}>
          <Text style={estilos.TextSearch}>{item.nome}</Text>
          <Text style={estilos.TextSearch}>{item.ingredientes}</Text>
          <Text style={estilos.TextSearch}>{item.preparo}</Text>
          </View>
        } />
      </View>
      </ScrollView>
    )
  }
}