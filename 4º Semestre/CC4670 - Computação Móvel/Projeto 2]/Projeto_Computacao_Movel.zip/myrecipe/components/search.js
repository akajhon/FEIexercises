import React from 'react';
import { View,Text,Button,TextInput,FlatList,TouchableOpacity, ScrollView} from 'react-native';
import estilos from '../estilos';
import { db } from '../Config';

export class Search extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      nome: '',
      ingredientes: '',
      preparo: '',
      receitas: [],
    };
  }

  buscar() {
    db.ref('/receitas')
      .orderByChild('nome')
      .equalTo(this.state.nome)
      .on('value', (snapshot) => {
        let data = snapshot.val();
        if (data == null) alert('Não encontrado!');
        else {
          let dados = Object.values(data);
          this.setState({ receitas: dados });
        }
      });
  }

  render() {
    return (
      <View style={estilos.Body}>
      <ScrollView>
        <View style={estilos.Container}>
          <Text style={estilos.Text}>Nome da Receita: </Text>

          <TextInput
            style={estilos.Input}
            onChangeText={(texto) =>
              this.setState({ nome: texto })
            }></TextInput>

          <TouchableOpacity
            style={estilos.Button}
            onPress={() => this.buscar()}>
            {' '}
            <Text style={estilos.ButtonText}> Buscar </Text>{' '}
          </TouchableOpacity>

          <FlatList
            data={this.state.receitas}
            renderItem={({ item }) => (
              <View style={estilos.SubContainer}>
                <Text style={estilos.TextSearch}>{item.nome}</Text>
                <Text style={estilos.TextSearch}>{item.ingredientes}</Text>
                <Text style={estilos.TextSearch}>{item.preparo}</Text>
              </View>
            )}
          />
        </View>
        </ScrollView>
      </View>
    );
  }
}
