import React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DefaultTheme, DarkTheme } from '@react-navigation/native';
import { useColorScheme } from 'react-native';
import { Add } from './components/add';
import { Search } from './components/search';
import { List } from './components/list';
import { Timer } from './components/timer';

const Navegacao = createBottomTabNavigator();

export default class App extends React.Component{
    render(){
    return(
      <NavigationContainer theme={DarkTheme}>
        <Navegacao.Navigator>
        <Navegacao.Screen name="Salve sua receita" component={Add} 
           options={{
            tabBarLabel: "",
            tabBarActiveTintColor: 'tomato',
            tabBarInactiveTintColor: 'gray',
            tabBarIcon: ({color, size}) => (
            <MaterialCommunityIcons name="plus-circle-outline" color={color} size={32} />)
          }}
          />
          <Navegacao.Screen name="Buscar Receitas" component={Search} 
          options={{
            tabBarLabel: "",
            tabBarActiveTintColor: 'tomato',
            tabBarInactiveTintColor: 'gray',
            tabBarIcon: ({color, size}) => (
            <MaterialCommunityIcons name="magnify" color={color} size={32} />)
          }}
          />
          <Navegacao.Screen name="Cronômetro" component={Timer} 
           options={{
            tabBarLabel: "",
            tabBarActiveTintColor: 'tomato',
            tabBarInactiveTintColor: 'gray',
            tabBarIcon: ({color, size}) => (
            <MaterialCommunityIcons name="timer" color={color} size={32} />)
          }}
          />
            <Navegacao.Screen name="Seu Livro de Receitas" component={List} 
           options={{
            tabBarLabel: "",
            tabBarActiveTintColor: 'tomato',
            tabBarInactiveTintColor: 'gray',
            tabBarIcon: ({color, size}) => (
            <MaterialCommunityIcons name="format-list-bulleted-square" color={color} size={32} />)
          }}
          />
        </Navegacao.Navigator>
      </NavigationContainer>
    )
  }
}
