import {StyleSheet} from 'react-native';

const estilos = StyleSheet.create({
  Body:{
    height: '100%',
    width: '100%',
  },
  
  Container:{
    justifyContent: 'center',
    alignItems: 'center',
    margin: '5%',
  },

  Text: {
    fontSize: 22,
    color: "white",
    fontWeight: 'bold',
  },

  TextSearch:{
    fontSize: 15, 
    color: "white",
    fontWeight: 'bold',
  },

  Input:{
    height: 38,
    width: 250,
    borderColor: 'tomato',
    borderWidth: 2,
    borderRadius: 20,
    marginBottom: '5%',
    marginTop: '5%',
    color: 'white',
    padding: 10
  },

  InputTextArea:{
    height: 200,
    width: 250,
    color: 'white',
    borderColor: 'tomato',
    borderWidth: 2,
    borderRadius: 20,
    marginBottom: '5%',
    marginTop: '5%',
    textAlignVertical: 'top',
    padding: 10
  },

  Button:{
    marginTop: '5%',
    backgroundColor: 'tomato',
    padding: 10,
    borderRadius: 10
  },

  ButtonText:{
    fontSize: 15,
    color: "white",
    fontWeight: 'bold',
  },

  SubContainer:{
    flexDirection: 'column',
    justifyContent: "space-evenly",
    borderWidth: 2,
    borderRadius: 10,
    width: 250,
    borderColor: 'tomato',
    padding: 10,
    margin: 10
  },

  SubcontainerText: {
    fontSize: 15,
    fontColor: "white",
    fontWeight: 'bold',
  },

  Timer:{
    flexDirection: "center",
    fontSize: 70,
    color: "tomato",
    fontWeight: 'bold',
  },

  TimerContainer:{
    margin: '35%',
    justifyContent: "center",
    alignItems: "center"
  }
});

export default estilos;