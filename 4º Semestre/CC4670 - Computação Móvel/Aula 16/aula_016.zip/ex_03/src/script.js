class FuncionariosDoHospital{
  constructor (nome){
    this._nome = nome;
    this._numeroRestanteDeFerias = 20;
  }
  
   get nome(){
    return this._nome;
  }
  
  set nome(nome){
    this._nome = nome;
  }
  
   get numeroRestanteDeFerias(){
    return this._numeroRestanteDeFerias;
  }
  
  set numeroRestanteDeFerias(numeroRestanteDeFerias){
    this._numeroRestanteDeFerias = numeroRestanteDeFerias;
  }
}

class Enfermeira extends FuncionariosDoHospital{
  constructor (nome,certificados){
    super(nome);
    this._certificados = certificados;
  }
  
  tirarFerias = (num_dias) => {
    console.log("[+] Você deve tirar " + num_dias + " dias de férias!!!");
    this._numeroRestanteDeFerias = this._numeroRestanteDeFerias - 2;
    console.log("[+] Ainda lhe resta " + this._numeroRestanteDeFerias  + " dias de férias!!!");
  }
  
  adicionarCertificado = (certificados) => {
    this._certificados = certificados + this._certificados;
    console.log("[+] Você ganhou " + certificados + " certificados!!!");
  }
}

class Medico extends FuncionariosDoHospital{
  constructor(nome, cpf){
    super(nome);
    this._cpf = cpf;
  }
  
  tirarFerias = (num_dias) =>{
    console.log("[+] Você deve tirar " + num_dias + " dias de férias!!!");
    this._numeroRestanteDeFerias = this._numeroRestanteDeFerias - 1;
    console.log("[+] Ainda lhe resta " + this._numeroRestanteDeFerias  + " dias de férias!!!");
  }
}

enfermeira = new Enfermeira('Maria', 2);
enfermeira.adicionarCertificado(5);
console.log("***********************" + "\n [+] Nome da Enfermeira: " + enfermeira.nome + " \n " + "[+] Total de Dias de férias: " + enfermeira.numeroRestanteDeFerias + " \n " + "[+] Total de Certificados: " + enfermeira._certificados + "\n************************");

medico = new Medico('João', 221200215);
console.log("***********************" + "\n [+] Nome do Médico: " + medico.nome + " \n " + "[+] Total de Dias de férias: " + medico.numeroRestanteDeFerias + " \n " + "[+] CPF: " + medico._cpf + "\n************************");

