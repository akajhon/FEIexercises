class VideoGame{
  constructor(marca, nControles, tipoMidia){
    this.marca = marca;
    this.Controles = nControles; 
    this.tipoMidia = tipoMidia;  
  }
  getMarca(){
    return this.marca;
  }
  
  setMarca(marca){
    this.marca = marca;
  }
  
  getControles(){
    return this.Controles;
  }
  
  setControles(Controles){
    this.Controles = Controles;
  }
  
  getTipoMidia(){
    return this.tipoMidia;
  }
  setTipoMidia(tipoMidia){
    this.tipoMidia = tipoMidia;
  }
  
}

playstation = new VideoGame('Sony', '2', 'DVD');
console.log(playstation.getMarca(), playstation.getControles(), playstation.getTipoMidia());


 function Jogar(){
    if (this.ligado == true){
    console.log("[+] Marca do Video Game: " + playstation.getMarca() + "\n" + " [+] Quantidade de Controles: "  + playstation.getControles());
    }else{
      console.log("[+] O seu Video Game está desligado!!!");
    }
  }
  
  function ligar(ligado){
    this.ligado = ligado;
  }
  
  function SalvarJogo(){
    console.log("[+] Salvando...");
  }
  

ligar(true);
Jogar();
SalvarJogo();