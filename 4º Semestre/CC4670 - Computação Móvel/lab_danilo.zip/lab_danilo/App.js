import * as React from 'react';
import { Text, View, StyleSheet, ImageBackground,TextInput,Button, Image} from 'react-native';
import {Audio} from 'expo-av';

class App extends React.Component{
  constructor(props){
    super(props);
    this.state={
      date: new Date(),
      hour: undefined,
      minute:undefined,
      validate: false
    }
    this.sound= new Audio.Sound(),
    this.sound.loadAsync(require('./assets/door_bell.wav'));
  }

  componentDidMount(){
    setInterval(()=>this.tick(), 1000);
  }

  tick(){
    this.setState({date: new Date()});
    this.clock();
  }

  clock(){
    if(parseInt(this.state.date.getHours()) == this.state.hour && parseInt(this.state.date.getMinutes()) == this.state.minute){
      this.sound.playAsync(),        
      this.setState({validate: true})
      setInterval(()=>{
        this.setState({validate: false})
      }, 5000);
    }
  }
  
//    <Image source={require('./assets/giphy.gif')} style={{width: 600, height: 600}}></Image>

  atualiza(){
      this.setState({validate: false})
  }

  render(){
    return(
      <View
        style={{display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-around',
        height: '100%'}}>
          <Text style={styles.texto}> </Text>
          <Text style={styles.texto}>hour:</Text>
          <TextInput style={styles.caixa} onChangeText={(texto)=> this.setState({hour: parseInt(texto)})}></TextInput>
          <Text style={styles.texto}>minute:</Text>
          <TextInput style={styles.caixa} onChangeText={(texto)=> this.setState({minute: parseInt(texto)})}></TextInput>
          {this.state.validate && <Image source={require('./assets/giphy.gif')} style={{width: 200, height: 200}}></Image>}
          <Text style={styles.texto}> </Text>
          <Text style={styles.texto}>{this.state.date.getDate()}/{this.state.date.getMonth()+1}/{this.state.date.getFullYear()}</Text>
          <Text style={styles.texto}>{this.state.date.toLocaleTimeString('pt-BR')}</Text>
          <Text style={styles.texto}> </Text>
          <Button title="Ativar" color="blue" onPress={() => this.atualiza()}></Button>
      </View>
    )
  }
}
const styles = StyleSheet.create({
  texto: {
    color: 'red',
    fontSize: 32,
    alignSelf:'center'
  },
  caixa: {
    fontSize: 25,
    paddingLeft: 20,
    borderColor: 'black',
    borderWidth: 2,
    borderRadius: 100,
    backgroundColor: "white",
    alignSelf:'center'
  }
});
export default App;