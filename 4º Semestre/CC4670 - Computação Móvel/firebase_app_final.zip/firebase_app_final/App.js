import React from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {MaterialCommunityIcons} from '@expo/vector-icons';


import { Buscar, Cadastro, Listar} from './components/componentes';


const Navegacao = createBottomTabNavigator();


export default class App extends React.Component{
  render(){
    return(
      <NavigationContainer>
        <Navegacao.Navigator>
        <Navegacao.Screen name="Cadastro" component={Cadastro} 
           options={{
            tabBarLabel: "Cadastro",
            tabBarIcon: ({color, size}) => (
            <MaterialCommunityIcons name="plus-circle-outline" color={color} size={32} />)
          }}
          />
          <Navegacao.Screen name="Buscar" component={Buscar} 
          options={{
            tabBarLabel: "Buscar",
            tabBarIcon: ({color, size}) => (
            <MaterialCommunityIcons name="magnify" color={color} size={32} />)
          }}
          />
          <Navegacao.Screen name="Listar" component={Listar} 
           options={{
            tabBarLabel: "Listar",
            tabBarIcon: ({color, size}) => (
            <MaterialCommunityIcons name="format-list-bulleted-square" color={color} size={32} />)
          }}
          />
        </Navegacao.Navigator>
      </NavigationContainer>
    )
  }
}

