import {StyleSheet} from 'react-native';

const estilos = StyleSheet.create({
  Body:{
    height: '100%',
    width: '100%',
    backgroundColor: 'gray',
  },
  Container:{
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'gray',
    margin: '8%',
    marginTop:'40%',
    padding: '10%',
  },
  Text: {
    fontSize: 18,
    color: "black",
    fontWeight: 'bold',
  },
  Input:{
    height: 38,
    width: 250,
    borderColor: 'black',
    borderWidth: 2,
    borderRadius: 20,
    marginBottom: '5%',
    marginTop: '5%',
  },
  Button:{
    fontSize: 18,
    fontWeight: 'bold'

  },
  SubContainer:{
    flexDirection: 'row',
    justifyContent: "space-between",
    backgroundColor: "gray",
    margin: 10
  },
});

export default estilos;
