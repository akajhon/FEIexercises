import React from 'react';
import { View, Text, Button, TextInput, FlatList } from 'react-native';
import estilos from '../estilos';
import { db } from '../config';

export class Cadastro extends React.Component {
  constructor(props) {
    super(props);
    this.marca = '';
    this.qnt = 0;
  }

  gravar() {
    db.ref('/notebooks').push({
      marca: this.state.marca,
      qnt: this.state.qnt
    })
    alert("Item Salvo.")
  }

  render() {
    return (
      <View style={estilos.Body}>
        <View style={estilos.Container}>
          <Text style={estilos.Text}>Marca do produto: </Text>
          
          <TextInput
            placeholder="  Marca"
            style={estilos.Input}
            onChangeText={(texto) => this.setState({marca: texto})}></TextInput>

          <Text style={estilos.Text}>Entre com a quantidade: </Text>

          <TextInput
            style={estilos.Input}
            placeholder="  Quantidade"
            onChangeText={(texto) => this.setState({qnt: texto})}></TextInput>

          <Button style={estilos.Button} title="Cadastrar" onPress={() => this.gravar()} />

        </View>
      </View>
    );
  }
}

export class Listar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      notebooks: []
    }
  }

  componentDidMount(){
    db.ref('/notebooks').on('value', snapshot => {
      let data = snapshot.val();
      let dados = Object.values(data);
      this.setState({notebooks: dados});
    })
  }

  render() {
    return (
      <View>
      <FlatList
        data = {this.state.notebooks}
        renderItem = {({item}) =>
          <View style={estilos.SubContainer}>
          <Text style={estilos.Text}>{item.marca}</Text>
          <Text style={estilos.Text}>{item.qnt}</Text>
          </View>
        } />
      </View>
    )
  }
}

export class Buscar extends React.Component{

  constructor(props){
    super(props);
    this.state = {
      marca:'',
      notebooks: []
    }
  }

  buscar(){
    db.ref('/notebooks')
      .orderByChild("marca")
      .equalTo(this.state.marca)
      .on('value', snapshot =>{
        let data = snapshot.val();
        if(data==null)
          alert("Não encontrado.")
        else{
          let dados = Object.values(data);
          this.setState({notebooks: dados});
        }
      })
  }

  render() {
    return (
      <View style={estilos.Body}>
        <View style={estilos.Container}>
          <Text style={estilos.Text}>Marca do Produto: </Text>
          
          <TextInput
            placeholder=" Marca:"
            style={estilos.Input}
            onChangeText={(texto) => this.setState({marca: texto})}></TextInput>

          <Button style={estilos.Button} title="Buscar" onPress={() => this.buscar()} />
          

          <FlatList
          data = {this.state.notebooks}
          renderItem = {({item}) =>
            <View style={estilos.SubContainer}>
            <Text style={estilos.SubContainer}>{item.marca}</Text>
            <Text style={estilos.SubContainer}>{item.qnt}</Text>
            </View>
          } />

        </View>
      </View>
    );
  }

}

