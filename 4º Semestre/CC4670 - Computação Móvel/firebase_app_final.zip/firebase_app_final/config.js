import Firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyAr5a16GD1luMo0S7gsY6541Q3sNMWxbXg",
  authDomain: "fir-app-cc4670.firebaseapp.com",
  databaseURL: "https://fir-app-cc4670-default-rtdb.firebaseio.com",
  projectId: "fir-app-cc4670",
  storageBucket: "fir-app-cc4670.appspot.com",
  messagingSenderId: "749353271641",
  appId: "1:749353271641:web:ca70ca850f78e091c30c48"
};

const fire = Firebase.initializeApp(firebaseConfig);
export const db = fire.database();