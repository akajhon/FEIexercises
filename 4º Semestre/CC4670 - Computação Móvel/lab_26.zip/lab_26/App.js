import React from "react";
import { View, Text } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import { Cadastro, MainStackNavigator } from "./components/Principal";

const Navegacao = createBottomTabNavigator();

class App extends React.Component {
  render() {
    return (
      <NavigationContainer>
        <Navegacao.Navigator>
          <Navegacao.Screen
            name="Login"
            component={MainStackNavigator}
            options={{
              tabBarLabel: "Login",
              tabBarIcon: ({ color, size }) => (
                <MaterialCommunityIcons name="account-check" color={color} size={35} />
              ),
            }}
          />
          <Navegacao.Screen
            name="Cadastro"
            component={Cadastro}
            options={{
              tabBarLabel: "Cadastrar",
              tabBarIcon: ({ color, size }) => (
                <MaterialCommunityIcons
                  name="account-plus-outline"
                  color={color}
                  size={32}
                />
              ),
            }}
          />
        </Navegacao.Navigator>
      </NavigationContainer>
    );
  }
}

export default App;
