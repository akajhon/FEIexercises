import React, { useState } from "react";
import { Text, TextInput, TouchableOpacity, View, StyleSheet, AsyncStorage,ScrollView} from "react-native";
import { createStackNavigator } from "@react-navigation/stack";

const MainStack = createStackNavigator();

export const MainStackNavigator = ({ navigation, route }) => {
  return (
    <MainStack.Navigator>
      <MainStack.Screen
        options={{ headerShown: false }}
        name="Login"
        component={Login}
      />
      <MainStack.Screen
        options={{ headerShown: false }}
        name="ListaDeFilmes"
        component={ListaDeFilmes}
      />
      <MainStack.Screen
        options={{ headerShown: true }}
        name="DescricaoDoFilme"
        component={DescricaoDoFilme}
      />
    </MainStack.Navigator>
  );
};

export const Login = ({ navigation, route }) => {
  const [usuario, setUsuario] = useState("");
  const [senha, setSenha] = useState("");

  const logar = () => {
    AsyncStorage.getItem(usuario, (erro, valor) => {
      if (erro == undefined && valor != null) {
        if (senha == valor) {
          alert("Logado!!!");
          navigation.navigate("ListaDeFilmes");
        } else {
          alert("Senha incorreta!!!");
        }
      } else {
        alert("Usuário não encontrado!!!!");
      }
    });
  };

  return (
    <View style={styles.container}>
      <View style={styles.entradaView}>
        <TextInput
          style={styles.entrada}
          placeholder="User"
          onChangeText={(entrada) => setUsuario(entrada)}
        />
      </View>
      <View style={styles.entradaView}>
        <TextInput
          style={styles.entrada}
          placeholder="Password"
          secureTextEntry={true}
          onChangeText={(entrada) => setSenha(entrada)}
        />
      </View>
      <View style={styles.buttonView}>
        <TouchableOpacity style={styles.botao} onPress={() => logar()}>
          <Text style={styles.botao}>{"Entrar"}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export const Cadastro = ({ nagivation, route }) => {
  const [usuario, setUsuario] = useState("");
  const [senha, setSenha] = useState("");

  const cadastrar = () => {
    AsyncStorage.setItem(usuario, senha, (erro) => {
      if (erro == undefined) {
        alert("Cadastrado com sucesso!!!");
      } else {
        alert("Erro ao Cadastrar!!!");
      }
    });
  };

  return (
    <View style={styles.container}>
      <View style={styles.entradaView}>
        <TextInput
          style={styles.entrada}
          placeholder="User"
          onChangeText={(entrada) => setUsuario(entrada)}
        />
      </View>
      <View style={styles.entradaView}>
        <TextInput
          style={styles.entrada}
          placeholder="Password"
          secureTextEntry={true}
          onChangeText={(entrada) => setSenha(entrada)}
        />
      </View>
      <View style={styles.buttonView}>
        <TouchableOpacity style={styles.botao} onPress={() => cadastrar()}>
          <Text style={styles.botao}>{"Cadastrar"}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export const DescricaoDoFilme = ({ navigate, route }) => {
  return (
    <ScrollView>
      <Text style={styles.texto}>{route.params.filmeEscolhido.nome}</Text>
      <Text style={styles.texto}>{route.params.filmeEscolhido.descricao}</Text>
    </ScrollView>
  );
};

export const ListaDeFilmes = ({ navigation, route }) => {
  const filmes = [
    {
      nome: "O Senhor dos Aneis",
      descricao:
        "O Senhor dos Anéis (no original em inglês, The Lord of the Rings) é uma trilogia cinematográfica dirigida por Peter Jackson com base na obra-prima homónima de J. R. R. Tolkien. Os três filmes foram rodados em simultâneo na Nova Zelândia,[1] faturaram cerca de 3 bilhões (US$ 2.925.155.189) de dólares de receitas conjuntas de bilheteira[2] e foram galardoados com 17 Oscars, entre os 30 para os quais foram nomeados.[3] e é a franquia cinematográfica mais premiada da história. Localizada no mundo ficcional na Terra Média, os três filmes seguem o jovem hobbit Frodo Bolseiro em sua missão de destruir o Anel assegurando assim também a destruição de seu criador, o Senhor das Trevas Sauron. Para auxiliá-lo em sua tarefa, forma-se uma sociedade, composta por representantes dos humanos, hobbits, elfos e anões, encarregados de sua segurança pelos estranhos caminhos que terá que seguir. No entanto, a sociedade quebra-se e Frodo continua sua jornada sozinho, apenas acompanhado por seu amigo fiel, Samwise Gamgee, e pelo traiçoeiro Gollum, um dos antigos possuidores do Anel. Ao mesmo tempo, o mago Gandalf e o humano Aragorn, herdeiro exilado do trono de Gondor, unem-se e juntam o Povo Livre da Terra Média em uma guerra, finalmente vitoriosa, contra Sauron. ",
    },
    {
      nome: "The Siege of Jadotville",
      descricao:
        "The Siege of Jadotville é um filme de guerra e drama histórico de 2016, dirigido por Richie Smyth e escrito por Kevin Brodbin. O filme é baseado no livro de Declan Power, The Siege at Jadotville: The Irish Army's Forgotten Battle (2005), sobre o papel de uma unidade do Exército Irlandês na missão de manutenção da paz da ONU no Congo em setembro de 1961. "
    },
    {
      nome: "Bastardos Inglórios",
      descricao:
        "Durante a Segunda Guerra Mundial, na França, um grupo de judeus americanos conhecidos como Bastardos espalha o terror entre o terceiro Reich. Ao mesmo tempo, Shosanna, uma judia que fugiu dos nazistas, planeja vingança quando um evento em seu cinema reunirá os líderes do partido.",
    },
    {
      nome: "Luca",
      descricao:
        "Luca vive aventuras com seu novo melhor amigo, mas a diversão é ameaçada por um segredo: seu amigo é um monstro marinho de outro mundo que fica abaixo da superfície da água.",
    },
  ];

  return (
    <View>
      {filmes.map((filme) => {
        return (
          <TouchableOpacity style={styles.botao} onPress={() => navigation.navigate("DescricaoDoFilme", { filmeEscolhido: filme })}>
            <Text style={styles.botao}>{filme.nome}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    display: "flex",
    height: "100%",
    alignItems: "center",
  },
  entradaView: {
    width: "70%",
    height: 45,
    marginBottom: 20,
    alignItems: "center",
  },
  entrada: {
    height: 50,
    flex: 1,
    padding: 10,
    marginLeft: 10,
  },
  botao: {
    alignItems: "center",
    padding: 10,
  },
  texto: {
    fontSize: 24,
    padding: 50,
    marginBottom: 10,
  },
});