package s10ex2;

public class Pessoa {
    private String nome,tel;; 
    
    int id;
    static int nextid = 1;  

    public Pessoa(String nome, String tel) {
        this.nome = nome;
        this.tel = tel;
        this.id = nextid++;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static int getNextid() {
        return nextid;
    }

    public static void setNextid(int nextid) {
        Pessoa.nextid = nextid;
    }

    @Override
    public String toString() {
        return "pessoa{" + "nome=" + nome + ", telofone=" + tel+ ", id=" + id + '}';
    }
    
    
 
    
}
