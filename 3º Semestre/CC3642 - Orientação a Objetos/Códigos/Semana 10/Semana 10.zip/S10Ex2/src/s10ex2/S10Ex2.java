
package s10ex2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class S10Ex2 {

    public static void main(String[] args) {
     
    int op;
    int contador=1;
    
    Scanner entrada = new Scanner (System.in);
    ArrayList <Pessoa> lista = new ArrayList <>();
    File arquivo = new File("Contato.txt");
    
          
    String nome,telefone; 
    
   
           
    do{
       
        System.out.println("Entre com uma opção");
        System.out.println("1 - Nova Entrada:");
        System.out.println("2 - Apagar Registro:");
        System.out.println("3 - Imprimir Registro:");
        System.out.println("0 - Sair:");
        
        op = Integer.parseInt(entrada.nextLine());
        
        if(op == 1){
          
                
            for(int j =  0; j<contador; j++){
                System.out.println("Entre com o nome: ");
                nome = entrada.nextLine();
                System.out.println("Entre com o numero:");
                telefone = entrada.nextLine();

                lista.add(new Pessoa(nome, telefone));

                System.out.println("Deseja cadastrar mais um usuario ? ");
                System.out.println("1 - Sim ");
                System.out.println("2 - Não ");
                int op2; 
                op2 = Integer.parseInt(entrada.nextLine());

                if(op2 == 1){
                    contador++;
                    System.out.println(contador);
                }
                
                if(op2 == 2){
                   try{
                      FileWriter fw = new FileWriter(arquivo,true);
                      BufferedWriter bw = new BufferedWriter(fw); 
                      
                      for(Pessoa i: lista){
                      bw.write(i.getNome());
                      bw.write(i.getTel());
                      bw.write(i.getId());
                      bw.newLine(); 
                      }
                            
                      bw.close();
                      fw.close(); 
                   
                   } 
                
                   catch(Exception e){
                        e.printStackTrace();
                    }
                   System.out.println("Cadastrado com sucesso!!!");
                   return;
                
                }
            }
             
             
        }
      
     
       if(op == 2){
           
            try{
                
                FileReader fr = new FileReader (arquivo);
                BufferedReader br = new  BufferedReader(fr);
                ArrayList<String> conteudo = new ArrayList<>();
                String linha;
                
                String nome_compara;
                System.out.println("Entre com o nome que deseja excluir:");
                nome_compara = entrada.nextLine();
                
               
                
                 while((linha = br.readLine()) !=null){
                    if(linha.equals(nome_compara+" ") == false){
                        conteudo.add(linha);
                    }
                 
                }
                
                br.close();
                fr.close();
                
                for(int i = 0; i<conteudo.size(); i++){
                    System.out.println(conteudo.get(i));
                
                }
               
               
            
            }
                
           catch(Exception e){
               e.printStackTrace();
   
       }
    }
       
    if(op == 3){
           try{
                FileReader fr = new FileReader (arquivo);
                BufferedReader br = new  BufferedReader(fr);
                ArrayList<String> conteudo = new ArrayList<>();
                String str;
                while((str = br.readLine()) !=null){
                    
                    conteudo.add(str);
                
                }
                br.close();
                fr.close();
                
                for(int i = 0; i<conteudo.size(); i++){
                    System.out.println(conteudo.get(i));
                
                }
            }
                
           catch(Exception e){
               e.printStackTrace();
           }
           
         
 
       }
      
    
    } while(op != 0);
 }
    
}
