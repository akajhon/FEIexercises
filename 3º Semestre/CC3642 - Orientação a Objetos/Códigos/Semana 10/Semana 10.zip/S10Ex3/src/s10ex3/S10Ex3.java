package s10ex3;

public class S10Ex3 {
        public static void main (String[] args){
            Triple <Integer, Double,String> triplo = new Triple <> (10, 20.5, "Cinco"); 
            
            System.out.println("[+] Valores originais: ");
            System.out.println(triplo);
            
            System.out.println("");
            Triple <String,Double,String> triplo2 = new Triple <> ("Trinta e Cinco", 5.5, "Número Vinte e Cinco");
            System.out.println("[+] Valores Alterados: ");
            System.out.println(triplo2);
            }
}
