package s10ex3;

public class Triple <F,S,T> {
    private F primeiro;
    private S segundo;
    private T terceiro; 

    public Triple(F primeiro, S segundo, T terceiro) {
        this.primeiro = primeiro;
        this.segundo = segundo;
        this.terceiro = terceiro;
    }

    public F getPrimeiro() {
        return primeiro;
    }

    public void setPrimeiro(F primeiro) {
        this.primeiro = primeiro;
    }

    public S getSegundo() {
        return segundo;
    }

    public void setSegundo(S segundo) {
        this.segundo = segundo;
    }

    public T getTerceiro() {
        return terceiro;
    }

    public void setTerceiro(T terceiro) {
        this.terceiro = terceiro;
    }

    @Override
    public String toString() {
        return  "[*] Primeiro:" + primeiro + "\n[*] Segundo:" + segundo +"\n[*] Terceiro:" + terceiro;    }
    
    
    


    
}


