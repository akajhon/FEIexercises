package s10ex1;

public interface Print {
    void print(String nome);   
}
