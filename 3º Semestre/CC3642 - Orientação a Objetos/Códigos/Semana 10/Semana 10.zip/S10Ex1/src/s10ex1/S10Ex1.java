
package s10ex1;
import java.util.Random;

public class S10Ex1 {

    public static void main(String[] args) {
        // TODO code application logic here
        Random gerador = new Random();
        Factory fabrica = new Factory();
        Print imp;
        for(int i=0;i<20;i++){
            int NumRandom = gerador.nextInt(2);
            if(NumRandom ==1){
                imp = fabrica.getInstance("Tela");
                imp.print("João Pedro Rosa - 22.120.021-5");
            }
            else if(NumRandom == 0){
                imp=fabrica.getInstance("Arquivo");
                imp.print("João Pedro Rosa - 22.120.021-5");
            }
        }
    }
    
}
