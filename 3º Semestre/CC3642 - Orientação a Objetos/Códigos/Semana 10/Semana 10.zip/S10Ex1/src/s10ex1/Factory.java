package s10ex1;

public class Factory {
   public Print getInstance(String tipo){
       if(tipo.equalsIgnoreCase("tela")){
           return  printTela.getInstance();    
        }
       
       else if(tipo.equalsIgnoreCase("arquivo")){
           return printArq.getInstance();
  
        }
       
       else{
           return null; 
       }
   }   
}
