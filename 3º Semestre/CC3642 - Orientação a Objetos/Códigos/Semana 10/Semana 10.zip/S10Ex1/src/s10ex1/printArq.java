package s10ex1;

import java.io.FileWriter;
import java.io.PrintWriter;

public class printArq implements Print{
    private static printArq state; 
    private printArq(){};
 
    public static printArq getInstance(){
        if(state == null){
               state = new printArq(); 
        }
        return state; 
    }

    @Override
    public void print(String nome) {
        try{
        FileWriter arquivo = new FileWriter("saida.txt");
        PrintWriter escrita_arquivo = new PrintWriter(arquivo);
        escrita_arquivo.println(nome); 
        arquivo.close(); 
        }
 
        catch(Exception e ){
            e.printStackTrace();
        } 
    }   
}
