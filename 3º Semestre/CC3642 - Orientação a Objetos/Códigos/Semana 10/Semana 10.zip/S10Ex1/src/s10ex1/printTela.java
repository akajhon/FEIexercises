package s10ex1;

public class printTela implements Print {
    private static printTela state; 
    private printTela(){};
    
    public static printTela getInstance(){
        if(state == null){
               state = new printTela(); 
        }
        return state; 
    }
    
    @Override
    public void print(String nome) {
        System.out.println(nome);
    }
    
    
    
}
