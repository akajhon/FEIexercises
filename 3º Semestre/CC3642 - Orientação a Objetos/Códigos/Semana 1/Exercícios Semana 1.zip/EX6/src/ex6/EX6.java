package ex6;
import java.util.Scanner;


public class EX6 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        float salario, porcent, salario_ajustado,reajuste;
        System.out.printf("Digite o seu salário atual:  ");
        salario = input.nextFloat();
        
        if(salario > 0 && salario <= 400){
            porcent = (float) 0.15;
            salario_ajustado = (salario * porcent) + salario;
            reajuste = (salario * porcent);
            System.out.println("*************************************");
            System.out.printf("Novo salário = R$%.2f\n", salario_ajustado);
            System.out.printf("Valor ganho com o reajuste = R$%.2f\n", reajuste);
            System.out.printf("Percentual de reajuste = %.2f%%\n" , porcent*100 );
            System.out.println("*************************************");
        }
        else if(salario >= 400.01 && salario <= 800){
            porcent = (float) 0.12;
            salario_ajustado = (salario * porcent) + salario;
            reajuste = (salario * porcent);
            System.out.println("*************************************");
            System.out.printf("Novo salário = R$%.2f\n", salario_ajustado);
            System.out.printf("Valor ganho com o reajuste = R$%.2f\n", reajuste);
            System.out.printf("Percentual de reajuste = %.2f%%\n" , porcent*100 );
            System.out.println("*************************************");
        }
        else if(salario >= 800.01 && salario <= 1200){
            porcent = (float) 0.1;
            salario_ajustado = (salario * porcent) + salario;
            reajuste = (salario * porcent);
            System.out.println("*************************************");
            System.out.printf("Novo salário = R$%.2f\n", salario_ajustado);
            System.out.printf("Valor ganho com o reajuste = R$%.2f\n", reajuste);
            System.out.printf("Percentual de reajuste = %.2f%%\n" , porcent*100 );
            System.out.println("*************************************");
        }
        else if(salario >= 1200.01 && salario <= 2000){
            porcent = (float) 0.07;
            salario_ajustado = (salario * porcent) + salario;
            reajuste = (salario * porcent);
            System.out.println("*************************************");
            System.out.printf("Novo salário = R$%.2f\n", salario_ajustado);
            System.out.printf("Valor ganho com o reajuste = R$%.2f\n", reajuste);
            System.out.printf("Percentual de reajuste = %.2f%%\n" , porcent*100 );
            System.out.println("*************************************");
        }
        else if(salario >= 2000){
            porcent = (float) 0.04;
            salario_ajustado = (salario * porcent) + salario;
            reajuste = (salario * porcent);
            System.out.println("*************************************");
            System.out.printf("Novo salário = R$%.2f\n", salario_ajustado);
            System.out.printf("Valor ganho com o reajuste = R$%.2f\n", reajuste);
            System.out.printf("Percentual de reajuste = %.2f%%\n" , porcent*100 );
            System.out.println("*************************************");
        }
        
    }
    
}