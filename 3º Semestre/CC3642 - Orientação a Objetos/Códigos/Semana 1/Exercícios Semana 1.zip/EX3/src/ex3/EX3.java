package ex3;
import java.util.Scanner;
public class EX3 {
    
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        int num = 0, i=0, cont=0;
        
        while(num < 20){
            System.out.print("Digite o número desejado: ");
            num = input.nextInt();
            if (num >0){
                i++;
            }
            cont++;
        }
        System.out.printf("Foram Digitados " + i + " números positivos\n");
}
}
        

   
