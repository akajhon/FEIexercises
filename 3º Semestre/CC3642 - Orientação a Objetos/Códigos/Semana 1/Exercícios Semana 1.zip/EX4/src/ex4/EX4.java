package ex4;
import java.util.Scanner;

public class EX4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int op, quant, menu;
        double total =0, valorTotal = 0;
        do{
        System.out.println("Digite o número do produto vendido: (1 - 5) ");
        op = input.nextInt();
        System.out.println("Digite a quantidade vendida: ");
        quant = input.nextInt();
        switch(op){
        case 1:
            total = 2.98 * quant;
            System.out.println("*****************************");
            System.out.printf("Valor Vendido: R$%.2f\n", total);
            System.out.println("*****************************");
            break;
        case 2:
            total = 4.50 * quant;
            System.out.println("*****************************");
            System.out.printf("Valor Vendido: R$%.2f\n", total);
            System.out.println("*****************************");
            break;
        case 3:
            total = 3.98 * quant;
            System.out.println("*****************************");
            System.out.printf("Valor Vendido: R$%.2f\n", total);
            System.out.println("*****************************");
            break;
        case 4:
            total = 4.49 * quant;
            System.out.println("*****************************");
            System.out.printf("Valor Vendido: R$%.2f\n", total);
            System.out.println("*****************************");
            break;
        case 5:
            total = 6.87 * quant;
            System.out.println("*****************************");
            System.out.printf("Valor Vendido: R$%.2f\n", total);
            System.out.println("*****************************");
            break;
                   
        default:
            System.out.println("Opção inválida!!!");
            break;
        }
        
        valorTotal = valorTotal + total;
        System.out.println("Digite 0 para sair ou 1 para continuar vendendo...");
        menu = input.nextInt();

        }
        while(menu !=0);
            System.out.println("*****************************************");
            System.out.printf("Valor Total de venda: R$%.2f\n", valorTotal);
            System.out.println("*****************************************");
            System.out.println("Saindo...");
    }
}