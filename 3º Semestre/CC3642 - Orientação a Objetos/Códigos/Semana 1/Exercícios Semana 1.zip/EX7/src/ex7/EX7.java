package ex7;

import java.util.Scanner;

public class EX7 {

public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int i;
        System.out.println("Digite o número desejado: ");
        
        for(int count = 0;count < 5; count++){
            i = input.nextInt();
            for(int temp =0 ;temp < i; temp++){
                System.out.printf("*");
                
            }
            System.out.println("");
        }
        
    }
    
}