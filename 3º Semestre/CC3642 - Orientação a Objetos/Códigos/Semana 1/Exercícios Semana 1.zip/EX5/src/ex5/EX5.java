package ex5;
import java.util.Scanner;

public class EX5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int portinhaP, portinhaR;
        
        System.out.print("Digite a posição da Portinha P 1/0: ");
        portinhaP = input.nextInt();
        
        System.out.print("Digite a posição da Portinha R 1/0: ");
        portinhaR = input.nextInt();
        
        if (portinhaP == 0){
            System.out.print("A Bolinha cairá pelo caminho: C\n");
        }
        else if(portinhaP == 1 && portinhaR == 1){
            System.out.print("A Bolinha cairá pelo caminho: A\n");
        }
        else if(portinhaP == 1 && portinhaR == 0){
            System.out.print("A Bolinha cairá pelo caminho: B\n");
        }
    }
    
}
