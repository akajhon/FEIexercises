package ex8;
import java.lang.Math;

public class EX8 {

    public static void main(String[] args) {
        double catad, catop, hip, Catetos, Hipotenusa;
        
        for(hip = 1; hip<500; hip++){
            for(catad =1; catad<500; catad++){
                for(catop = 1; catop<500; catop++){
                    Catetos = Math.pow(catad, 2) + Math.pow(catop, 2);
                    Hipotenusa = Math.pow(hip, 2);
                    
                if(Catetos == Hipotenusa) {
                    System.out.println("São Triplos de Pitágoras: ");
                    System.out.println("Hipotenusa = "+ hip);
                    System.out.println("Cateto Adjacente = "+ catad);
                    System.out.println("Cateto Oposto = "+ catop);
                    System.out.println("***************************");
                }
                
            }
        }
    }
    
    
  }
}