package ex2;
public class EX2 {
    
    public static void main(String[] args){
        int imp;
        System.out.println("Números Impares encontrados: ");
        for (imp = 0; imp <1001; imp++ ){
            if(imp%2 != 0){
                System.out.println(imp);
            }
        }
}
}
        

   
