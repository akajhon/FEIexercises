package s8e3;

public interface IWalkable {
    public void andar();
}
