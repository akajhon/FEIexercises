package s8e3;

public class Morcego extends Animal implements IWalkable, IFlyable {

    @Override
    public void andar(){
        System.out.println("Aqui o " + nome + " está andando!!!");
    }
    
    @Override
    public void voar(){
        System.out.println("Aqui o " + nome + " voando!!!");
    }

    public Morcego(String nome) {
        super(nome);
    }

    public Morcego() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
    
     
}
