package s8e3;

public interface IFlyable {
    public void voar();
}
