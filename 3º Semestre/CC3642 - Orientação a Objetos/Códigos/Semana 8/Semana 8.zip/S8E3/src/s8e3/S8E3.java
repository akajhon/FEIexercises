package s8e3;

public class S8E3 {
    public static void main(String[] args) {
        IFlyable batman1;
        IWalkable batman2;
        
        batman1 = new Morcego("Morcego");
        batman1.voar();
        System.out.println(" ");
        batman2 = new Morcego("Morcego");
        batman2.andar();
        
        
    }
    
}
