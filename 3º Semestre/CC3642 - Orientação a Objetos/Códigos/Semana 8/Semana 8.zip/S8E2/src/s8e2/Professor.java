package s8e2;

public class Professor extends Agente {
    public String nome, profissao, escola;
    public boolean modo_agente;

    public Professor(String nome, String profissao, String escola, boolean modo_agente) {
        this.nome = nome;
        this.profissao = profissao;
        this.escola = escola;
        this.modo_agente = modo_agente;
    }

    public Professor() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    public String getEscola() {
        return escola;
    }

    public void setEscola(String escola) {
        this.escola = escola;
    }

    public boolean isModo_agente() {
        return modo_agente;
    }

    public void setModo_agente(boolean modo_agente) {
        this.modo_agente = modo_agente;
    }
    
    @Override
    public void apresentacao(boolean modo_agente){
        if(modo_agente == true){
            System.out.println("[+]Função: Professor" + "\n[+]Nome: " + nome + "\n[+]Profissão: " + profissao + 
                "\n[+]Escola: " + escola + "\n[+]Modo_agente: AGENTE SMITH");
        }
        else{
            System.out.println("[+]Função: Professor" + "\n[+]Nome: " + nome + "\n[+]Profissão: " + profissao + 
                "\n[+]Escola: " + escola);
        }
    }
}
