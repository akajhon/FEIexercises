package s8e2;

public class Advogado extends Agente {
    public String nome, profissao, OAB;
    public boolean modo_agente;

    public Advogado(String nome, String profissao, String OAB, boolean modo_agente) {
        this.nome = nome;
        this.profissao = profissao;
        this.OAB = OAB;
        this.modo_agente = modo_agente;
    }

    public Advogado() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    public String getOAB() {
        return OAB;
    }

    public void setOAB(String OAB) {
        this.OAB = OAB;
    }

    public boolean isModo_agente() {
        return modo_agente;
    }

    public void setModo_agente(boolean modo_agente) {
        this.modo_agente = modo_agente;
    }
    
    @Override
    public void apresentacao(boolean modo_agente){
        if(modo_agente == true){
            System.out.println("[+]Função: Advogado" + "\n[+]Nome: " + nome + "\n[+]Profissão: " + profissao + 
                "\n[+]OAB: " + OAB + "\n[+]Modo_agente: AGENTE SMITH");
        }
        else{
            System.out.println("[+]Função: Advogado" + "\n[+]Nome: " + nome + "\n[+]Profissão: " + profissao + 
                "\n[+]OAB: " + OAB);
        }
        
    }
    
}
