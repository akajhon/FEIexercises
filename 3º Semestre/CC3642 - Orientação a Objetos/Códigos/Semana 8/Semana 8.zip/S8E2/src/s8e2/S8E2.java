package s8e2;
import java.util.ArrayList;
import java.util.Scanner;

public class S8E2{
    public static void main(String[] args) {
        boolean count = true;
        boolean modo_agente = false;
        String nome, profissao, work, agente;
        int op2;
   
        ArrayList<Agente> newPeople = new ArrayList<>();
        Scanner input = new Scanner(System.in);
        
        while(count == true){
            System.out.println("======= Bem-vindo a Matrix =======");
            System.out.println("[1] - Cadastrar um Empresário.");
            System.out.println("[2] - Cadastrar um Advogado.");
            System.out.println("[3] - Cadastrar um Professor.");
            System.out.println("[4] - Mostrar pessoas cadastradas.");
            System.out.println("[5] - Sair.");
            System.out.println("==================================");
            System.out.println("Sua opção >>");
            op2 = Integer.parseInt(input.nextLine());
             
            if(op2 == 1){
                System.out.println("Nome: ");
                nome = input.nextLine();
                System.out.println("Profissão: ");
                profissao = input.nextLine();
                System.out.println("Empresa: ");
                work = input.nextLine();
                newPeople.add(new Empresario(nome, profissao, work, modo_agente));
             
            }
            
            else if(op2 == 2){
                System.out.println("Nome: ");
                nome = input.nextLine();
                System.out.println("Profissão: ");
                profissao = input.nextLine();
                System.out.println("OAB: ");
                work = input.nextLine();
                newPeople.add(new Advogado(nome, profissao, work, modo_agente));
                
            }
            
            else if(op2 == 3){
                System.out.println("Nome: ");
                nome = input.nextLine();
                System.out.println("Profissão: ");
                profissao = input.nextLine();
                System.out.println("Escola em que atua: ");
                work = input.nextLine();
                newPeople.add(new Professor(nome, profissao, work, modo_agente));
            }
            
            else if(op2 == 4){
                System.out.println("Digite o nome da pessoa para ser agente: ");
                agente = input.nextLine();
                for(int j = 0; j < newPeople.size(); j++){
                    if(agente.equals(newPeople.get(j).getNome()) == true){
                        modo_agente = true;
                    }
                System.out.println("=============== Pessoas Cadastradas: ===============");
                newPeople.get(j).apresentacao(modo_agente);
                modo_agente = false;
                System.out.println(" ");
                }    
            }
            
            else if(op2 == 5){
                System.out.println("Saindo do programa!!!");
                count = false;
            }
            
            else if(op2 > 0 || op2 < 6){
                System.out.println("Opcão inválida! Digite novamente!!!");
            }
            
        }
    }
}
          
    

    
