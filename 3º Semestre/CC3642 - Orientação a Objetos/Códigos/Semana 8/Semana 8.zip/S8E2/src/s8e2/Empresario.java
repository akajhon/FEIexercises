package s8e2;

public class Empresario extends Agente {
    public String nome, profissao, empresa;
    public boolean modo_agente;

    public Empresario(String nome, String profissao, String empresa, boolean modo_agente) {
        this.nome = nome;
        this.profissao = profissao;
        this.empresa = empresa;
        this.modo_agente = modo_agente;
    }

    public Empresario() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public boolean isModo_agente() {
        return modo_agente;
    }

    public void setModo_agente(boolean modo_agente) {
        this.modo_agente = modo_agente;
    }
    
    @Override
    public void apresentacao(boolean modo_agente){
        if(modo_agente == true){
            System.out.println("[+]Função: Empresário" + "\n[+]Nome: " + nome + "\n[+]Profissão: " + profissao + 
                "\n[+]Empresa: " + empresa + "\n[+]Modo_agente: AGENTE SMITH");
        }
        else{
            System.out.println("[+]Função: Empresário" + "\n[+]Nome: " + nome + "\n[+]Profissão: " + profissao + 
                "\n[+]Empresa: " + empresa);
        }
        
    }
}
