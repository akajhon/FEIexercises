package s8e1;

public class S8E1 {

    public static void main(String[] args) {
        int x = 20;
        int y = 50;
        int xSpeed = 5;
        int ySpeed = 2;
        int raio = 2;
        
        Movable obMovel = new MovablePoint(x, y, xSpeed, ySpeed);
        System.out.println(obMovel);
        obMovel.moveDown();
        obMovel.moveRight();
        System.out.println(obMovel);
        System.out.println(" ");
        
        obMovel = new MovableCircle(x, y, xSpeed, ySpeed, raio);
        System.out.println(obMovel);
        obMovel.moveUp();
        obMovel.moveLeft();
        System.out.println(obMovel);
        System.out.println(" ");
        
    }
    
}
