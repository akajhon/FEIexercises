/**
 *
 * @author AKAJhon
 * @version 1.0
 */

package DAO;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import Model.Aluno;
import java.sql.ResultSet;

public class AlunoDAO {
    private final Connection connect;

    public AlunoDAO(Connection connect) {
        this.connect = connect;
    }
    public void insertAluno(Aluno aluno) throws SQLException{
        String SQL = "INSERT INTO aluno(nome,usuario,senha)"
                +"values('"+aluno.getNome()+"', '"+aluno.getUsuario()+"', '"+aluno.getSenha()+"')";
        PreparedStatement statement = connect.prepareStatement(SQL);
        statement.execute();
        connect.close();
    }
    public ResultSet consultAluno(Aluno aluno) throws SQLException{
        String sql = "SELECT * FROM aluno WHERE usuario = ? AND senha = ?";
        PreparedStatement statement = connect.prepareStatement(sql);
        statement.setString(1,aluno.getUsuario());
        statement.setString(2, aluno.getSenha());
        statement.execute();
        ResultSet answer = statement.getResultSet();
        connect.close();
        return answer;
    }
    public ResultSet deleteAluno(Aluno aluno) throws SQLException{
        String sql = "DELETE FROM aluno WHERE usuario = ? AND senha = ?";
        PreparedStatement statement = connect.prepareStatement(sql);
        statement.setString(1,aluno.getUsuario());
        statement.setString(2, aluno.getSenha());
        statement.execute();
        ResultSet answer = statement.getResultSet();
        connect.close();
        return answer;
    }
    
}
