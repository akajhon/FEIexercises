package DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *  @version 1.0
 * @author AKAJhon
 */

public class Connectiondb {
    public Connection getConnection() throws SQLException{
        Connection connect= DriverManager.getConnection("jdbc:postgresql://localhost:5432/alunosdb","postgresql","teste123");
        return connect;
    }
}
