/**
 * @author AKAjhon
 * @version 1.0
 */
package PostgreeSQL;
import View.loginWindow;

public class PostGree {
    public static void main(String[] args) {
        loginWindow window = new loginWindow();
        window.setVisible(true);
    }
    
}
