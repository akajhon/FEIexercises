package Controller;
import DAO.Connectiondb;
import DAO.AlunoDAO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Model.Aluno;
import View.deleteWindow;

/**
 * @author AKAJhon
 * @version 1.0
 */

public class DeleteController {
    private deleteWindow view;

    public DeleteController(deleteWindow view) {
        this.view = view;
    }
    public void deletarAluno(){
        Aluno aluno = new Aluno(null,view.getUserbox().getText(),view.getPassbox().getText());
        Connectiondb connect = new Connectiondb();
        try{
            Connection connection = connect.getConnection();
            AlunoDAO dao = new AlunoDAO(connection);
            ResultSet answer = dao.consultAluno(aluno);
            if(answer.next()){
                JOptionPane.showMessageDialog(view,"[+] User deleted!\n"
                        +"\n[=] User: "+answer.getString(2)
                        ,"Sucesso",JOptionPane.INFORMATION_MESSAGE);
                connection = connect.getConnection();
                dao = new AlunoDAO(connection);
                answer = dao.deleteAluno(aluno);
            }
            else{
                JOptionPane.showMessageDialog(view,"[+] Usuário Errado!","Erro",JOptionPane.ERROR_MESSAGE);
            }
        }
        catch(SQLException e){
           e.printStackTrace();
        }
    }
}
