package Controller;
import DAO.Connectiondb;
import DAO.AlunoDAO;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Model.Aluno;
import View.cadastroWindow;

/**
 * @author AKAJhon
 * @version 1.0
 */

public class RegisterController {
    private cadastroWindow view;

    public RegisterController(cadastroWindow view) {
        this.view = view;
    }
    public void cadastraAluno(){
        String nome = view.getBoxName().getText();
        String login = view.getBoxLogin().getText();
        String senha = view.getBoxPass().getText();
        Aluno aluno = new Aluno(nome,login,senha);
        Connectiondb connect = new Connectiondb();
        try{
            Connection connection = connect.getConnection();
            AlunoDAO dao = new AlunoDAO(connection);
            dao.insertAluno(aluno);
            JOptionPane.showMessageDialog(view,"[+] Usuário Registrado!","Sucesso",JOptionPane.INFORMATION_MESSAGE);

        }
        catch(SQLException e){
            JOptionPane.showMessageDialog(view,"[+] Erro durante o Registro!","Erro",JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
