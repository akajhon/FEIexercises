package Controller;
import DAO.Connectiondb;
import DAO.AlunoDAO;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Model.Aluno;
import View.loginWindow;

/**
 * @author AKAJhon
 * @version 1.0
 */

public class LoginController {
    private loginWindow view;

    public LoginController(loginWindow view) {
        this.view = view;
    }
    public void loginAluno(){
        Aluno aluno = new Aluno(null,view.getUserbox().getText(),view.getPassbox().getText());
        Connectiondb connect = new Connectiondb();
        try{
            Connection connection = connect.getConnection();
            AlunoDAO dao = new AlunoDAO(connection);
            ResultSet answer = dao.consultAluno(aluno);
            if(answer.next()){
                answer.getString(1);
                JOptionPane.showMessageDialog(view,"[+] O Login está Correto!\n"
                        + "\n[+] Nome: "+answer.getString(1)+ 
                        "\n[+] Usuário: "+answer.getString(2)+ 
                        "\n[+] Senha: "+answer.getString(3)
                        ,"Login",JOptionPane.INFORMATION_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(view,"[+] Login Incorreto!","Erro",JOptionPane.ERROR_MESSAGE);
            }
        }
         catch(SQLException e){
             e.printStackTrace();
         }
    }
}
