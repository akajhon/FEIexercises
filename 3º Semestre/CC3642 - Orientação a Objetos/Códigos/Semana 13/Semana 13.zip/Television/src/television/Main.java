package television;
import View.Janela;

/**
 *
 * @author akajhon
 */
public class Main {
   public static void main(String[] args) {
        Janela j = new Janela();
        j.setVisible(true);
    }
}
