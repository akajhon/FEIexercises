package Controller;
import View.Janela;
import Model.Televisao;


public class Controller {
    private Janela view;

    public Controller(Janela view) {
        this.view = view;
    }
    
    // TODO: Funções da televisão
    public void aumentaCanal() {
        int canalAtual = view.getTelevision().getCanal();
        view.getTelevision().setCanal(canalAtual + 1);
    }
    
    public void diminuiCanal() {
        int canalAtual = view.getTelevision().getCanal();
        if ((canalAtual - 1) < 0)
            view.getTelevision().setCanal(0);
        else
            view.getTelevision().setCanal(canalAtual - 1);
    }
    
    public void mudaVolume(int volume) {
        view.getTelevision().setVolume(volume);
    }
          
    public void ligaTV() {
        view.getTelevision().setLigada(true);
    }
    
    public void desligaTV() {
        view.getTelevision().setLigada(false);
    }
}
