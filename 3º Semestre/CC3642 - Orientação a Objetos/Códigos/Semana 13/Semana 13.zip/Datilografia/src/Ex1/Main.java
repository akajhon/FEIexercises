package Ex1;

/**
 *
 * @author Akajhon
 */
public class Main {
    public static void main(String[] args) {
        Janela windows = new Janela();
        windows.setVisible(true);
    }
    
}
