package Model;

/**
 *
 * @author akajhon
 */
public class urano extends planetas{
    
    @Override
    public float calcular(float peso){
        return peso*=1.17;
    }
}
