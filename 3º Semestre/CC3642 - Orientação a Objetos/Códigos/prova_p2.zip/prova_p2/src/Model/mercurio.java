package Model;

/**
 *
 * @author akajhon
 */
public class mercurio extends planetas {
    
    @Override
    public float calcular(float peso){
        return peso*=0.37;
    }
}
