package Model;

/**
 *
 * @author akajhon
 */
public class saturno extends planetas {
    
    @Override
    public float calcular(float peso){
        return peso*=1.15;
    }
}
