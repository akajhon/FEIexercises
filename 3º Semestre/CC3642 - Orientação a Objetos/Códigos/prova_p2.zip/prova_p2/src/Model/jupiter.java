package Model;

/**
 *
 * @author akajhon
 */
public class jupiter extends planetas {
    
    @Override
    public float calcular(float peso){
        return peso*=2.64;
    }
}
