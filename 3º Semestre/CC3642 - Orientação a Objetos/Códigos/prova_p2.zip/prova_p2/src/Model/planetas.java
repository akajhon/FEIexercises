package Model;

/**
 *
 * @author akajhon
 */
public abstract class planetas {
    public abstract float calcular(float peso);
}
