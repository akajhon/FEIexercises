package Model;
/**
 *
 * @author akajhon
 */
public class marte extends planetas{
    
    @Override
    public float calcular(float peso){
        return peso*=0.38;
    }
    
}
