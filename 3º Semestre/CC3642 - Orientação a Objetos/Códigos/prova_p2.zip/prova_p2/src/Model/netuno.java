package Model;

/**
 *
 * @author akajhon
 */
public class netuno extends planetas {
    
    @Override
    public float calcular(float peso){
        return peso*=1.18;
    }
}
