package Model;

/**
 *
 * @author akajhon
 */
public class venus extends planetas {
    
    @Override
    public float calcular(float peso){
        return peso*=0.88;
    }
}
