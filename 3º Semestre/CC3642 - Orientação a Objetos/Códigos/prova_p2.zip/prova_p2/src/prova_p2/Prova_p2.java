package prova_p2;
import View.Janela;

/**
 *
 * @author akajhon
 */
public class Prova_p2 {
    public static void main(String[] args) {
        Janela window = new Janela();
        window.setVisible(true);
    }
    
}
