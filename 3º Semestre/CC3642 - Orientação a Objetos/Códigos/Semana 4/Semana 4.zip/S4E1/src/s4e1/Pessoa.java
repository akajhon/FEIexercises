package s4e1;

public class Pessoa {
    private String nome, telefone;
    private static int nextId = 1;
    int id;

    public Pessoa(String nome, String telefone) {
        this.nome = nome;
        this.telefone = telefone;
        this.id = nextId++;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        return "*** Contato ***" + "\n[+] Nome = " + nome + "\n[+] Telefone = " + telefone + "\n[+] ID = " + id;
    }
   
}
