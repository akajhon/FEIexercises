package s4e1;
import java.util.ArrayList;
import java.util.Scanner;

public class S4E1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Pessoa> people = new ArrayList<>();
        String entrada;
        
            do{
            System.out.println("\nEntre com uma das opções abaixo: ");
            System.out.println("[+] n - Nova Entrada");
            System.out.println("[+] d - Apagar registro da Agenda");
            System.out.println("[+] p - Visualizar toda a agenda");
            System.out.println("[+] q - Sair");
            entrada = input.nextLine();
           
            if(entrada.equals("n")){
                String name, number;
                
                System.out.println("[-] Digite o nome do contato:");
                name = input.nextLine();
                System.out.println("[-] Digite o número do contato:");
                number = input.nextLine();
                
                people.add(new Pessoa(name, number));
            }
            
            else if(entrada.equals("d")){
                String name;
                System.out.println("[-] Digite o nome do contato que deseja remover:");
                name = input.nextLine();
                for (int i = 0; i < people.size(); i++){
                    if(people.get(i).getNome().equals(name))
                        people.remove(i);
                        System.out.println("Contato excluído da agenda!!!");
                }
            }
            
            else if(entrada.equals("p")){
                System.out.println("** Imprimindo sua agenda... **");
                System.out.println(" ");
                for(Pessoa agenda:people)
                    System.out.println(agenda);
            }
           
            }while(entrada.equals("q") != true);
            System.out.println("** Saindo!!! **");
        }
        
    }