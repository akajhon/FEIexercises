package s4e2;

public class Roda {
   private int R1, R2, R3, R4;

    public int getR1() {
        return R1;
    }

    public void setR1(int R1) {
        this.R1 = R1;
    }

    public int getR2() {
        return R2;
    }

    public void setR2(int R2) {
        this.R2 = R2;
    }

    public int getR3() {
        return R3;
    }

    public void setR3(int R3) {
        this.R3 = R3;
    }

    public int getR4() {
        return R4;
    }

    public void setR4(int R4) {
        this.R4 = R4;
    }

    @Override
    public String toString() {
        return "Roda{" + "R1=" + R1 + ", R2=" + R2 + ", R3=" + R3 + ", R4=" + R4 + '}';
    }
   
}
