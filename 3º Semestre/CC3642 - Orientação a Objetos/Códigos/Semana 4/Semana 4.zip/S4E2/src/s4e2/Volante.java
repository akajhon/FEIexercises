package s4e2;
public class Volante {
    private String volante;

    public String getVolante() {
        return volante;
    }

    public void setVolante(String volante) {
        this.volante = volante;
    }

    @Override
    public String toString() {
        return "Volante{" + "volante=" + volante + '}';
    }
    
    
}
