package s4e2;
import java.util.ArrayList;

public class S4E2 {
    public static void main(String[] args) {
        ArrayList<Carro> newCar = new ArrayList<>();
        
        newCar.add(new Carro());
        newCar.add(new Carro());
        newCar.add(new Carro());
        
        System.out.println("Carros Registrados: ");
        for(Carro carro:newCar)
                System.out.println(carro);
        System.out.println("********************");
    }
    
}
