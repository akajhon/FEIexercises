package s4e2;

public class Porta {
    private int P1, P2, P3, P4, P5;

    public int getP1() {
        return P1;
    }

    public void setP1(int P1) {
        this.P1 = P1;
    }

    public int getP2() {
        return P2;
    }

    public void setP2(int P2) {
        this.P2 = P2;
    }

    public int getP3() {
        return P3;
    }

    public void setP3(int P3) {
        this.P3 = P3;
    }

    public int getP4() {
        return P4;
    }

    public void setP4(int P4) {
        this.P4 = P4;
    }

    public int getP5() {
        return P5;
    }

    public void setP5(int P5) {
        this.P5 = P5;
    }

    @Override
    public String toString() {
        return "Porta{" + "P1=" + P1 + ", P2=" + P2 + ", P3=" + P3 + ", P4=" + P4 + ", P5=" + P5 + '}';
    }
    
}
