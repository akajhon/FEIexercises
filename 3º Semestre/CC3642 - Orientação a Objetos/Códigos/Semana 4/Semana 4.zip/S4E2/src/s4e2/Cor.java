package s4e2;

public class Cor {
    private String cor;

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    @Override
    public String toString() {
        return "Cor{" + "cor=" + cor + '}';
    }
    
}
