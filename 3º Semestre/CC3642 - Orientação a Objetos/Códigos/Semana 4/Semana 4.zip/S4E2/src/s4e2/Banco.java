package s4e2;

public class Banco {
    private int B1, B2, B3, B4;

    public int getB1() {
        return B1;
    }

    public void setB1(int B1) {
        this.B1 = B1;
    }

    public int getB2() {
        return B2;
    }

    public void setB2(int B2) {
        this.B2 = B2;
    }

    public int getB3() {
        return B3;
    }

    public void setB3(int B3) {
        this.B3 = B3;
    }

    public int getB4() {
        return B4;
    }

    public void setB4(int B4) {
        this.B4 = B4;
    }

    @Override
    public String toString() {
        return "Banco{" + "B1=" + B1 + ", B2=" + B2 + ", B3=" + B3 + ", B4=" + B4 + '}';
    }
    
}
