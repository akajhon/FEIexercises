package s4e2;

public class Rádio {
    private boolean radio;

    public boolean isRadio() {
        return radio;
    }

    public void setRadio(boolean radio) {
        this.radio = radio;
    }

    @Override
    public String toString() {
        return "Radio{" + "radio=" + radio + '}';
    }
    
}
