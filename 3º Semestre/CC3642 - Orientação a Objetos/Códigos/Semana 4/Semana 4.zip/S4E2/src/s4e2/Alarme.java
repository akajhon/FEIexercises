package s4e2;

public class Alarme {
    private boolean alarme;

    public boolean isAlarme() {
        return alarme;
    }

    public void setAlarme(boolean alarme) {
        this.alarme = alarme;
    }

    @Override
    public String toString() {
        return "Alarme{" + "alarme=" + alarme + '}';
    }
    
}
