package s4e2;
public class Motor {
    private String motor;

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }

    @Override
    public String toString() {
        return "Motor{" + "motor=" + motor + '}';
    }
    
    
}
