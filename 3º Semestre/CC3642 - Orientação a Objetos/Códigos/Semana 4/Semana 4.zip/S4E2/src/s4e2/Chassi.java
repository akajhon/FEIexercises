package s4e2;

public class Chassi {
    private String nChassi;

    public String getnChassi() {
        return nChassi;
    }

    public void setnChassi(String nChassi) {
        this.nChassi = nChassi;
    }

    @Override
    public String toString() {
        return "Chassi{" + "nChassi=" + nChassi + '}';
    }
    
}
