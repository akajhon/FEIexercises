package s5ex3;
/**
 * Subclasse CheckingAccount - Feito por João Pedro
 * 23/03/2021
 * @author akajhon
 */
public class CheckingAccount extends Account{
    double taxTransacao = 0.10;

    public CheckingAccount(double taxTransacao, double balance) {
        super(balance);
        this.taxTransacao = taxTransacao;
    }

    public double getTaxTransacao() {
        return taxTransacao;
    }

    public void setTaxTransacao(double taxTransacao) {
        this.taxTransacao = taxTransacao;
    }

    @Override
    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getAdd() {
        return add;
    }

    public void setAdd(double add) {
        this.add = add;
    }

    public double getWithdraw() {
        return withdraw;
    }

    public void setWithdraw(double withdraw) {
        this.withdraw = withdraw;
    }
    
    @Override
    public String getBalance() {
        return super.getBalance(); 
    }

    @Override
    public void debit(double withdraw) {
        taxTransacao = 0.10;
        withdraw = withdraw - ((balance + withdraw)*taxTransacao);
        super.debit(withdraw);
    }

    @Override
    public void credit(double add) {
        taxTransacao = 0.10;
        add = add - ((balance + add)*taxTransacao);
        super.credit(add);     
    }
}