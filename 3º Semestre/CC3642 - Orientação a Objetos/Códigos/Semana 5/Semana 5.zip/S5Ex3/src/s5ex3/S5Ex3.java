package s5ex3;
import java.util.Scanner;
/**
 * Main - S5Ex3 - Feito por João Pedro
 * 23/03/2021
 * @author akajhon
 */

public class S5Ex3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double balance, add, withdraw;
        int op, opAccount;
        Scanner input = new Scanner(System.in);
        System.out.println("**** BANCO CENTRAL ****");
        System.out.println("[1] - Conta poupança");
        System.out.println("[2] - Conta corrente");
        System.out.println("[0] - Sair");
        System.out.println("[+] Digite a opção desejada: ");
        opAccount = input.nextInt();
        
        System.out.println(" ");
        System.out.println("[+] Digite seu saldo: ");
        balance = input.nextDouble();
       
        while(opAccount >-1 || opAccount < 3){
            if(opAccount == 1){
                 
                SavingsAccount sa = new SavingsAccount(0,balance);
                
                System.out.println(" ");
                System.out.println("[1] - Creditar");
                System.out.println("[2] - Debitar");
                System.out.println("[3] - Ver o Saldo atual");
                System.out.println("[0] - Retornar");
                System.out.println("[+] Digite a opção desejada: ");
                op = input.nextInt();
            
                while(op>-1 || op < 4){
                    if(op == 1){
                        System.out.println(" ");
                        System.out.println("[-] Digite o valor que deseja creditar: ");
                        add = input.nextDouble();
                        sa.credit(add);
                        
                    }


                    else if(op == 2){
                        System.out.println(" ");
                        System.out.println("[-] Digite o valor que deseja debitar: ");
                        withdraw = input.nextDouble();
                        sa.debit(withdraw);

                    }

                    else if(op == 3){
                        System.out.println(" ");
                        System.out.println(sa.getBalance());
                        System.out.println("[-] Sua Taxa de Juros é: "+ sa.calculateInterest() + "%");
                    }
                    else if(op == 0){
                        System.out.println(" ");
                        System.out.println("[+] Voltando ao menu principal!!!");
                        break;


                    }
                    System.out.println(" ");
                    System.out.println("[1] - Creditar");
                    System.out.println("[2] - Debitar");
                    System.out.println("[3] - Saldo atual");
                    System.out.println("[0] - Retornar");
                    System.out.println("[+] Digite a opção desejada: ");
                    op = input.nextInt();

                    }

            }
            else if(opAccount == 2){
                CheckingAccount ca = new CheckingAccount(0,balance);
           
                System.out.println(" ");
                System.out.println("[1] - Creditar");
                System.out.println("[2] - Debitar");
                System.out.println("[3] - Ver o Saldo atual");
                System.out.println("[0] - Retornar");
                System.out.println("[+] Digite a opção desejada: ");
                op = input.nextInt();
            
                while(op>-1 || op < 4){
                    if(op == 1){
                        System.out.println(" ");
                        System.out.println("[+] Digite o valor que deseja creditar: ");
                        add = input.nextDouble();
                        ca.credit(add);
                        
                    }


                    else if(op == 2){
                        System.out.println(" ");
                        System.out.println("[-] Digite o valor que deseja debitar: ");
                        withdraw = input.nextDouble();
                        ca.debit(withdraw);

                    }

                    else if(op == 3){
                        System.out.println(ca.getBalance());
                        System.out.println("[-] Sua Taxa de Juros é: " + "10%");
                    }
                    else if(op == 0){
                        System.out.println(" ");
                        System.out.println("[+] Retornando ao menu principal!!!");
                        break;


                    }
                    System.out.println(" ");
                    System.out.println("[1] - Creditar");
                    System.out.println("[2] - Debitar");
                    System.out.println("[3] - Saldo atual");
                    System.out.println("[0] - Sair");
                    System.out.println("[+] Digite a opção desejada: ");
                    op = input.nextInt();

                    }
            }
            else if(opAccount == 0){
                System.out.println(" ");
                System.out.println("[+] Obrigado por utilizar nossos serviços!!!");
                System.out.println("[*] Saindo...");
                break;
            }
            
            System.out.println(" ");
            System.out.println("[1] - Conta Poupança.");
            System.out.println("[2] - Conta Corrente.");
            System.out.println("[0] - Sair.");
            System.out.println("[+] Digite a conta desejada: ");
            opAccount = input.nextInt();

        }
    }
    
}