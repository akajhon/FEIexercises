package s5ex3;
/**
 * Subclasse SavingsAccount - Feito por João Pedro
 * 23/03/2021
 * @author akajhon
 */

public class SavingsAccount extends Account{
    double juros = 0.05;
    
    public SavingsAccount(double juros, double balance) {
        super(balance);
        this.juros = juros;
    }
    
    public double calculateInterest(){
        double juros = 0.05;
        return balance * juros;
    }
    
    public double getJuros() {
        return juros;
    }

    public void setJuros(double juros) {
        this.juros = juros;
    }

    public double getSaldo() {
        return balance;
    }

    public void setSaldo(double balance) {
        this.balance = balance;
    }

    public double getAdd() {
        return add;
    }

    public void setAdd(double add) {
        this.add = add;
    }

    public double getWithdraw() {
        return withdraw;
    }

    public void setWithdraw(double withdraw) {
        this.withdraw = withdraw;
    }

    @Override
    public String getBalance() {
        return super.getBalance(); 
    }

    @Override
    public void credit(double add) {
        super.credit(add);
    }

    @Override
    public void debit(double withdraw) {
        super.debit(withdraw);
    }
}