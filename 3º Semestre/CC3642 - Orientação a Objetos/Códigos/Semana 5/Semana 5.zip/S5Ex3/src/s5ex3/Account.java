package s5ex3;
import java.text.DecimalFormat;
/**
 * SuperClasse - Account - Feito por João Pedro
 * 23/03/2021
 * @author akajhon
 */
public class Account {
    double balance, add, withdraw;
    boolean verifica;


    public Account(double balance) {
        if(balance >= 0){
            this.balance = balance;
        }
        else{
            this.balance = 0.0;
            System.out.println("[+] Saldo inicial inválido!!! ");
        }
        
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }


    public void credit( double add){

        balance += add;
        

    }
    public void debit(double withdraw){
        if(balance < withdraw){
            System.out.println("[-] Saldo insuficiente!!! ");
        }else{
           balance -= withdraw;
        }

    }
    public String getBalance(){
        return "[+] Seu saldo atual é: R$" + new DecimalFormat("#,##0.00").format(balance);
        
    }

    
}