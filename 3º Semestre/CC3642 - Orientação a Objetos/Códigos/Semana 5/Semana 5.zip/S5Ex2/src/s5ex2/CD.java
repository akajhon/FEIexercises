package s5ex2;
import java.util.ArrayList;

/**
 * Subclasse - CD - Feito por Akajhon
 * 23/03/2021
 * @author akajhon
 */
public class CD extends Produto{
    private String genero, nFaixas;
    private int preco;
    private ArrayList<String> faixas;

    public CD(String genero, String nFaixas, int preco, ArrayList<String> faixas, String nome, String tipo) {
        super(nome, tipo);
        this.genero = genero;
        this.nFaixas = nFaixas;
        this.preco = preco;
        this.faixas = faixas;
    }

    public CD(String genero, String nFaixas, int preco, ArrayList<String> faixas) {
        this.genero = genero;
        this.nFaixas = nFaixas;
        this.preco = preco;
        this.faixas = faixas;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getnFaixas() {
        return nFaixas;
    }

    public void setnFaixas(String nFaixas) {
        this.nFaixas = nFaixas;
    }

    public int getPreco() {
        return preco;
    }

    public void setPreco(int preco) {
        this.preco = preco;
    }

    public ArrayList<String> getFaixas() {
        return faixas;
    }

    public void setFaixas(ArrayList<String> faixas) {
        this.faixas = faixas;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "**** CD ****" + "\n[+] Nome: " + nome + "\n[+] Preço: R$ " + preco + "\n[+] Nº de Faixas: " + nFaixas + "\n[+] Nome de cada faixa: " + faixas + "\n";
    }
    
    
 
}
