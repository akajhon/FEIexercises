package s5ex2;

/**
 * Superclasse - Produto - Feito por Akajhon
 * 23/03/2021
 * @author akajhon
 */
public class Produto {
    protected String nome, tipo;

    public Produto(String nome, String tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }

    public Produto() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "*** Produto ***" + "\n[+] Nome: " + nome + "\n[+] Tipo: " + tipo;
    }
    
}
