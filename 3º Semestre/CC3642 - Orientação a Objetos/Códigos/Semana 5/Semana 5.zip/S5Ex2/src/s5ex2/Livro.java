package s5ex2;

/**
 * Subclasse - Livro - Feito por Akajhon
 * 23/03/2021
 * @author akajhon
 */
public class Livro extends Produto{
    private String genero, autor;
    private int preco;

    public Livro(String genero, String autor, int preco, String nome, String tipo) {
        super(nome, tipo);
        this.genero = genero;
        this.autor = autor;
        this.preco = preco;
    }

    public Livro(String genero, String autor, int preco) {
        this.genero = genero;
        this.autor = autor;
        this.preco = preco;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getPreco() {
        return preco;
    }

    public void setPreco(int preco) {
        this.preco = preco;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "**** Livro ****" + "\n[+] Nome: " + nome + "\n[+] Preço: R$ " + preco + "\n[+] Autor: " + autor + "\n[+] Gênero: " + genero + "\n";
    }

  
    
}
