package s5ex2;

/**
 * Subclasse - DVD - Feito por Akajhon
 * 23/03/2021
 * @author akajhon
 */
public class DVD extends Produto {
    private int preco;
    private double duracao;

    public DVD(int preco, double duracao, String nome, String tipo) {
        super(nome, tipo);
        this.preco = preco;
        this.duracao = duracao;
    }

    public DVD(int preco, double duracao) {
        this.preco = preco;
        this.duracao = duracao;
    }

    public int getPreco() {
        return preco;
    }

    public void setPreco(int preco) {
        this.preco = preco;
    }

    public double getDuracao() {
        return duracao;
    }

    public void setDuracao(double duracao) {
        this.duracao = duracao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "**** DVD ****" + "\n[+] Nome: " + nome + "\n[+] Preço: R$ " + preco + "\n[+] Duração: " + duracao +"hrs\n";
    }

  
}
