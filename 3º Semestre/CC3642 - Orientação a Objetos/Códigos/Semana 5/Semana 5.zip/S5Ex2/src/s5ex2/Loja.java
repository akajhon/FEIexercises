package s5ex2;
import java.util.ArrayList;

/**
 * Main - Loja - Feito por Akajhon
 * 23/03/2021
 * @author akajhon
 */
public class Loja {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Produto> produtos = new ArrayList<>();
        ArrayList<String> faixas = new ArrayList<>();
        
        produtos.add(new Livro("Aventura", "J.K.Rowling", 50, "Senhor dos Aneis", "Livro"));
        faixas.add("Faixa 1");
        faixas.add("Faixa 2");
        faixas.add("Faixa 3");
        produtos.add(new CD("Rock", "3",20, faixas," Live at the Hall", "CD"));
        produtos.add(new DVD(50, 2.30, "Hitman", "DVD"));
        produtos.add(new Livro("Aventura", "J.K.Rowling", 30, "Hobbit", "Livro"));
        produtos.add(new DVD(30, 1.30, "Minha mãe é uma peça", "DVD"));
        
       
        System.out.println(produtos.get(0));
        System.out.println(produtos.get(1));
        System.out.println(produtos.get(2));
        System.out.println(produtos.get(3));
        System.out.println(produtos.get(4));
    }
    
}
