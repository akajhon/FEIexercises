
package comissionemployee;
/**
 * Classe MAIN - Feito por Akajhon
 * 23/03/2021
 * @author akajhon
 */
public class Main {
    public static void main(String[] args) {
       
      BasePlusCommissionEmployee employee =             
         new BasePlusCommissionEmployee(                
         "João", "Pedro", "22.120.021-5", 1300, .04, 300 );
      
       
      System.out.println(
         "Employee information obtained by get methods: \n" );
      System.out.printf( "%s %s\n", "[+] First name is",
         employee.colaborador.getFirstName() );
      System.out.printf( "%s %s\n", "[+] Last name is", 
         employee.colaborador.getLastName() );
      System.out.printf( "%s %s\n", "[+] Social security number is", 
         employee.colaborador.getSocialSecurityNumber());
      System.out.printf( "%s %.2f\n", "[+] Gross sales is", 
         employee.colaborador.getGrossSales() );
      System.out.printf( "%s %.2f\n", "[+] Commission rate is",
         employee.colaborador.getCommissionRate() );
      System.out.printf( "%s %.2f\n", "[+] Base salary is",
         employee.getBaseSalary() );

      employee.setBaseSalary( 1000 );                                   
      
      System.out.printf( "\n%s:\n\n%s\n", 
         "Updated employee information obtained by toString",
         employee.toString());
      
      /** A abordagem por herança apresenta benefícios diversos, pois por ela 
       * escrevem-se menos linhas de código e o projeto acaba se tornando mais dinâmico
       * e consequentemente, mais fácil de compreender.
       * 
       * Na abordagem por Composição o projeto torna-se mais extenso e por seguinte, acaba ficando 
       * mais complicado para compreensão. O encapsulamento é mais forte em projetos que utilizam
       * a composição.
       * 
       * Por fim, conclui-se que a abordagem mais natural é a por herança, pois apresenta mais benefícios
       * ao projeto como um todo, tornando-o mais dinâmico, compreensível e organizado.
       */
    }
    
}
