package comissionemployee;
/**
 * Classe BasePlusCommissionEmployee - Feito por Akajhon
 * 23/03/2021
 * @author akajhon
 */
public class BasePlusCommissionEmployee {
    private double baseSalary;
    protected CommissionEmployee colaborador;

    public BasePlusCommissionEmployee(String first, String last, String ssn, 
      double sales, double rate, double salary) {
        colaborador = new CommissionEmployee(first, last, ssn, sales, rate);
        this.baseSalary = salary;
    }
    
    public void setFirstName(String nome){
       colaborador.setFirstName(nome);
    }
   
    public void setLastname(String sobrenome){
        colaborador.setLastName(sobrenome);
    }
    
    public void setSocialSecurityNumber(String numero){
        colaborador.setSocialSecurityNumber(numero);
    }
    
    public void setGrossSales( double vendas){
        colaborador.setGrossSales(vendas);
    }
    
    public void setCommissionRate( double taxa){
        colaborador.setCommissionRate(taxa);
    }
    
    public double getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }
    
    public double earnings(){
        return colaborador.earnings() + getBaseSalary();
    }

    @Override
    public String toString() {
        return "***** Empregado: *****" + "\n[+] Salário Base = " + baseSalary + "\n[+] Colaborador: " + colaborador;
    }
    
    
}   
