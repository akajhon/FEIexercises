package s3e1;


public class Racional {
    private int numerador, denominador, numerador2, denominador2;
    int num, den, deno2, num2;

    public int getNumerador2() {
        return numerador2;
    }

    public void setNumerador2(int numerador2) {
        this.numerador2 = numerador2;
    }

    public int getDenominador2() {
        return denominador2;
    }

    public void setDenominador2(int denominador2) {
        this.denominador2 = denominador2;
    }


    public Racional(int numerador, int denominador) {
        this.numerador = numerador;
        this.denominador = denominador;
    }

    public Racional() {
        this(0,0);
    }

    public int getNumerador() {
        return numerador;
    }

    public void setNumerador(int numerador) {
        this.numerador = numerador;
    }

    public int getDenominador() {
        return denominador;
    }

    public void setDenominador(int denominador) {
        this.denominador = denominador;
    }

    public int somaDeno(int a, int b){
        return a + b;
    }

    
    public int Maiordivisorcomum(int a, int b) {
        if (b == 0)
            return a;
        else
            return Maiordivisorcomum(b, a % b);
    }
    public void mdc (int nume , int deno){  
        int i = 1;  
        while(nume%i == 0 && deno%i == 0){  
            while (nume%i == 0){   
                nume = nume / i;  
                deno = deno / i ;
                int mdc = Maiordivisorcomum(nume, deno);
                    
                num = nume/mdc;
                den = deno/mdc;
                
                System.out.println(num + "/" + den);
                break;
            }
            
            i++;  
            
        }  
            
        }

    
    public void Soma(int a, int b, int c, int d){
        num2 = 0;
        deno2 = 0;
        if(b == d){
            int deno2 = b;
            int num2 = ((deno2/b*a)+(deno2/d*c));
            System.out.println("[+] A Soma dos racionais = "+num2+"/"+deno2);
            System.out.printf("[+] Multiplicação na forma reduzida = "); 
            mdc(num2, deno2);
        }
        else{
            int deno2 = (b*d);
            int num2 = ((deno2/b*a)+(deno2/d*c));  
            System.out.println("[+] A Soma dos racionais = "+num2+"/"+deno2);
            System.out.printf("[+] Multiplicação na forma reduzida = "); 
            mdc(num2, deno2);
           
        }
    
    }
    public void Subtracao(int a, int b, int c, int d){
        num2 = 0;
        deno2 = 0;
        if(b == d){
            int deno2 = b;
            int num2 = ((b/deno2)*a)-((d/deno2)*c);
            System.out.println("[+] A Subtração dos racionais = "+num2+"/"+deno2);
            System.out.printf("[+] Multiplicação na forma reduzida = "); 
            mdc(num2, deno2);
        }
        else{
            int deno2 = b*d;
            int num2 = ((deno2/b)*a)-((deno2/d)*c);
            System.out.println("[+] A Subtração dos racionais = "+num2+"/"+deno2);
            System.out.printf("[+] Multiplicação na forma reduzida = "); 
            mdc(num2, deno2);  

        }

    }
    
    public void Multiplicacao(int a, int b, int c, int d){
        num2 = 0;
        deno2 = 0;
        int num2 = a*c;
        int deno2 = b*d;
        System.out.println("[+] A Multiplicação dos racionais = "+num2+"/"+deno2);
        System.out.printf("[+] Multiplicação na forma reduzida = "); 
        mdc(num2, deno2);
        
        
    }
    
    public void Divisao(int a, int b, int c, int d){
        num2 = 0;
        deno2 = 0;
        int num2 = a*d;
        int deno2 = b*c;
        System.out.println("[+] A Divisão dos racionais = "+num2+"/"+deno2);
        System.out.printf("[+] Multiplicação na forma reduzida = "); 
        mdc(num2, deno2);
    }

    @Override
    public String toString() {
        return  "Número Racional 1 = "+numerador + "/" + denominador+"\n"+"Número Racional 2 = "+numerador2 + "/" + denominador2;
        
    }
    public String flutuante() {
        float nume = numerador;
        float deno = denominador;
        float a = nume/deno;
        String str = Float.toString(a);
        float N2 = numerador2;
        float D2 = denominador2;
        float b = N2/D2;
        String str2 = Float.toString(b);
       return "Número Flutuante (Racional 1) = "+ str+"\n"+"Número Flutuante (Racional 2) = "+ str2;
    }
    
}