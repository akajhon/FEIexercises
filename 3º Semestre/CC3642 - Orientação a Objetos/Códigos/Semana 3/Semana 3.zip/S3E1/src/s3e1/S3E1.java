package s3e1;
import java.util.Scanner;


public class S3E1 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Racional racional = new Racional();
        
        System.out.println("Digite o 1º Numerador: ");
        racional.setNumerador(input.nextInt());
        System.out.println("Digite o 1º Denominador: ");
        racional.setDenominador(input.nextInt());
        System.out.println("Digite o 2º Numerador: ");
        racional.setNumerador2(input.nextInt());
        System.out.println("Digite o 2º Denominador: ");
        racional.setDenominador2(input.nextInt());
        
        System.out.println("****** Resultado ******");
        racional.Soma(racional.getNumerador(),racional.getDenominador(), racional.getNumerador2(),racional.getDenominador2());
        racional.Subtracao(racional.getNumerador(),racional.getDenominador(), racional.getNumerador2(),racional.getDenominador2());
        racional.Multiplicacao(racional.getNumerador(),racional.getDenominador(), racional.getNumerador2(),racional.getDenominador2());
        racional.Divisao(racional.getNumerador(),racional.getDenominador(), racional.getNumerador2(),racional.getDenominador2());
        System.out.println(racional.toString());
        System.out.println(racional.flutuante());
        System.out.println("***********************");
       
        
    }
    
}