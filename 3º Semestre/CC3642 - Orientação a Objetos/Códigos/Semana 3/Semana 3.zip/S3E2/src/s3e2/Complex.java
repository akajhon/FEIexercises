package s3e2;

public class Complex {
    private float imaginario, real, imaginario2, real2;

    public Complex(float imaginario, float real, float imaginario2, float real2) {
        this.imaginario = imaginario;
        this.real = real;
        this.imaginario2 = imaginario2;
        this.real2 = real2;
    }
    public Complex() {
       imaginario = 1;
       real = 1;
       imaginario2 = 1;
       real2 = 1;
    }

    public float getImaginario() {
        return imaginario;
    }

    public void setImaginario(float imaginario) {
        this.imaginario = imaginario;
    }

    public float getReal() {
        return real;
    }

    public void setReal(float real) {
        this.real = real;
    }

    public float getImaginario2() {
        return imaginario2;
    }

    public void setImaginario2(float imaginario2) {
        this.imaginario2 = imaginario2;
    }

    public float getReal2() {
        return real2;
    }

    public void setReal2(float real2) {
        this.real2 = real2;
    }

    public void soma(float a, float b, float c, float d){
        float resultReal = a + c;
        float resultImaginario = b + d;
        System.out.println("[*] Soma dos Complexos = "+ resultReal + " + ("+resultImaginario+") * I");
        
    }
    public void subtracao(float a, float b, float c, float d){
        float resultReal = a-c;
        float resultImaginario = b-d;
        System.out.println("[*] Subtração dos Complexos = "+ resultReal + " + ("+resultImaginario+") * I");
        
    }
    
    
}