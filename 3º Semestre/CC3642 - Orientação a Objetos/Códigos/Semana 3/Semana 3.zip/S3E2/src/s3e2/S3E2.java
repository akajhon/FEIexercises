package s3e2;
import java.util.Scanner;

public class S3E2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        Complex resultado = new Complex();
        
        System.out.println("[+] Digite o 1º Número Real = ");
        resultado.setReal(input.nextFloat());
        
        System.out.println("[+] Digite o 2º Número Real = ");
        resultado.setReal2(input.nextFloat());
        
        System.out.println("[+] Digite o 1º Número Imaginário = ");
        resultado.setImaginario(input.nextFloat());
        
        System.out.println("[+] Digite o 2º Número Imaginário = ");
        resultado.setImaginario2(input.nextFloat());
        
        System.out.println(" ");
        System.out.println("***** Resultados *****");
        resultado.soma(resultado.getReal(),resultado.getImaginario() ,resultado.getReal2() , resultado.getImaginario2());
        resultado.subtracao(resultado.getReal(),resultado.getImaginario() ,resultado.getReal2() , resultado.getImaginario2());
        System.out.println("**********************");
    }
    
}