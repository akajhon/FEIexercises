package s3e3;

public class S3E3 {
       public static void main(String[] args) {
        
        aluno student = new aluno();
        disciplina subject = new disciplina();
        professor teacher = new professor();
            
        System.out.println("[+] A Relação entre as classes é de AGREGAÇÃO");
        System.out.println("[+] Pois as informações das Classes/Objetos precisam umas das outras para se complementarem");
        
        student.setDisciplina(subject);
        subject.setProfessor(teacher);
    }
    
}