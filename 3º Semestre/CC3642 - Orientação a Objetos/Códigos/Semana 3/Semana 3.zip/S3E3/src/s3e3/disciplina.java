package s3e3;

public class disciplina {
    private String nome, codigo;
    private professor Professor;

    public void setProfessor(professor Professor) {
        this.Professor = Professor;
    }
    
    public disciplina(){
        nome ="Orientação a Objetos";
        codigo = "CC3642";
        System.out.println("Nome da disciplina = "+nome);
        System.out.println("Código da disciplina = "+codigo);
        System.out.println("***********************");
    }
}