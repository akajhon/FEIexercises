package s3e3;

public class professor {
    private String nome, departamento;
    
    public professor(){
        nome  = "Danilo";
        departamento = "Computação";
        System.out.println("Nome do professor = "+nome);
        System.out.println("Departamento do professor = "+departamento);
        System.out.println("***********************");
    }
}