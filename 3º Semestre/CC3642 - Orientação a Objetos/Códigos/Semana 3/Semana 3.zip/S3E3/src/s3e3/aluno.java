package s3e3;

public class aluno {
    private String nome, RA, curso;
    private disciplina Disciplina;
    
    public aluno(){
        nome = "João Pedro";
        RA = "22.120.021-5";
        curso = "Ciência da Computação";
        System.out.println("******* INFOS ******");
       System.out.println("Nome do aluno = "+nome); 
       System.out.println("RA do aluno = "+RA); 
       System.out.println("Curso do aluno = "+curso);
       System.out.println("***********************");
       
    }

    public void setDisciplina(disciplina Disciplina) {
        this.Disciplina = Disciplina;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setRA(String RA) {
        this.RA = RA;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }
    

    
    
}