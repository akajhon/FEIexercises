package poupanca;
/**
 *
 * @author akajhon
 */
public class Poupanca {
   
    public static void main(String[] args) {
        Janela window = new Janela();
        window.setVisible(true);
    }
    
}
