package ex4;
import java.util.Scanner;

public class EX4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Invoice prod1 = new Invoice();
        Invoice prod2 = new Invoice();
        Invoice prod3 = new Invoice();
        Invoice prod4 = new Invoice();
        Invoice fatura = new Invoice();
        
        System.out.println("Digite o Identificador do Primeiro produto: ");
        prod1.setNumber(input.nextLine());
        System.out.println("Digite a descrição do Primeiro produto: ");
        prod1.setDescription(input.nextLine());
        System.out.println("Digite a quantidade do Primeiro produto: ");
        prod1.setQuantity(Integer.parseInt(input.nextLine()));
        System.out.println("Digite o valor do Primeiro produto: ");
        prod1.setPrice(Double.parseDouble(input.nextLine()));
        System.out.println(" ");
        
        System.out.println("Digite o Identificador do Segundo produto: ");
        prod2.setNumber(input.nextLine());
        System.out.println("Digite a descrição do Segundo produto: ");
        prod2.setDescription(input.nextLine());
        System.out.println("Digite a quantidade do Segundo produto: ");
        prod2.setQuantity(Integer.parseInt(input.nextLine()));
        System.out.println("Digite o valor do Segundo produto: ");
        prod2.setPrice(Double.parseDouble(input.nextLine()));
        System.out.println(" ");
        
        System.out.println("Digite o Identificador do Terceiro produto: ");
        prod3.setNumber(input.nextLine());
        System.out.println("Digite a descrição do Terceiro produto: ");
        prod3.setDescription(input.nextLine());
        System.out.println("Digite a quantidade do Terceiro produto: ");
        prod3.setQuantity(Integer.parseInt(input.nextLine()));
        System.out.println("Digite o valor do Terceiro produto: ");
        prod3.setPrice(Double.parseDouble(input.nextLine()));
        System.out.println(" ");
        
        System.out.println("Digite o Identificador do Quarto produto: ");
        prod4.setNumber(input.nextLine());
        System.out.println("Digite a descrição do Quarto produto: ");
        prod4.setDescription(input.nextLine());
        System.out.println("Digite a quantidade do Quarto produto: ");
        prod4.setQuantity(Integer.parseInt(input.nextLine()));
        System.out.println("Digite o valor do Quarto produto: ");
        prod4.setPrice(Double.parseDouble(input.nextLine()));
        System.out.println(" ");
        
        System.out.println("****** FATURA ******");
        fatura.getInvoiceAmount(prod1.getPrice(), prod2.getPrice(), prod3.getPrice(),prod4.getPrice(), prod1.getQuantity(), prod2.getQuantity(), prod3.getQuantity(), prod4.getQuantity());
        System.out.println(" ");
       
    }
    
}
