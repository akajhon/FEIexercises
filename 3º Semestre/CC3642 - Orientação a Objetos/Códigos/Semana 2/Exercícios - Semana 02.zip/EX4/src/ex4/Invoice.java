package ex4;

public class Invoice {
    private String number, description;
    private int quantity;
    private double price;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if(quantity < 0)
            this.quantity = 0;
        else
            this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if(price < 0)
            this.price = 0;
        else
            this.price = price;
    }

    @Override
    public String toString() {
        return "Invoice{" + "number=" + number + ", description=" + description + ", quantity=" + quantity + ", price=" + price + '}';
    }
    
    public double getInvoiceAmount(double price1, double price2, double price3, double price4, int qty1, int qty2, int qty3, int qty4){
        double total,total1, total2, total3, total4;
        total1 = price1 * qty1;
        total2 = price2 * qty2;
        total3 = price3 * qty3;
        total4 = price4 * qty4;
        total = total1 + total2 + total3 + total4;
        System.out.println("O Valor total da Fatura é de: R$" + total);
        return 0;
    } 
}
