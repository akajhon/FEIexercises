package ex5;

public class PerfilDeSaude {
    private int dia, mes, ano, anoAtual;
    private double altura, peso;
    private String nome, sobrenome, sexo;

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        if (dia > 31 )
            this.dia = 31;
        else if (dia < 01)
            this.dia = 01;
        else
            this.dia = dia;
    }
    
    public int getAnoAtual() {
        return anoAtual;
    }

    public void setAnoAtual(int anoAtual) {
        if(anoAtual < 0)
            this.anoAtual = 2021;
        else
            this.anoAtual = anoAtual;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        if (mes > 12 )
            this.mes = 12;
        else if (mes < 01)
            this.mes = 01;
        else
            this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        if (ano > 2021)
            this.ano = 2021;
        else if ( ano < 0)
            this.ano = 0;
        else
            this.ano = ano;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        if (altura > 3.0)
            this.altura = 3.0;
        else 
            this.altura = altura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    
    public double GetImc(){
        double IMC;
        IMC = this.peso/(this.altura*this.altura);
        return IMC;
    }
        
    public int birthDate(){
        int Year;
        Year = this.anoAtual - this.ano;
        return Year;
    }
}
