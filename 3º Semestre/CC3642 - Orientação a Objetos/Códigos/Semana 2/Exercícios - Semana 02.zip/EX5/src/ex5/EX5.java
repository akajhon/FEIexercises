package ex5;
import java.util.Scanner;

public class EX5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        PerfilDeSaude perfilSaude1 = new PerfilDeSaude();
        
        System.out.println("***** Cadastro de Saúde *****");
        System.out.println(" ");
        System.out.println("Digite seu Nome: ");
        perfilSaude1.setNome(input.nextLine());
        System.out.println("Digite seu Sobrenome: ");
        perfilSaude1.setSobrenome(input.nextLine());
        System.out.println("Digite seu sexo: ");
        perfilSaude1.setSexo(input.nextLine());
        System.out.println("Digite o dia do seu  nascimento: ");
        perfilSaude1.setDia(Integer.parseInt(input.nextLine()));
        System.out.println("Digite o mês do seu  nascimento: ");
        perfilSaude1.setMes(Integer.parseInt(input.nextLine()));
        System.out.println("Digite o ano do seu  nascimento: ");
        perfilSaude1.setAno(Integer.parseInt(input.nextLine()));
        System.out.println("Digite o ano atual: ");
        perfilSaude1.setAnoAtual(Integer.parseInt(input.nextLine()));
        System.out.println("Digite sua Altura em Metros: ");
        perfilSaude1.setAltura(Double.parseDouble(input.nextLine()));
        System.out.println("Digite seu Peso em KG: ");
        perfilSaude1.setPeso(Double.parseDouble(input.nextLine()));
        System.out.println("******************************");
        
        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");
        
        System.out.println("***** Cadastro Realizado *****");
        System.out.println("** Informações Cadastradas **");
        System.out.println(" Seu Nome: " + perfilSaude1.getNome());
        System.out.println(" Seu Sobrenome: " + perfilSaude1.getSobrenome());
        System.out.println(" Seu Sexo: " + perfilSaude1.getSexo());
        System.out.println(" Sua Data de nascimento: " +perfilSaude1.getDia()+"/"+perfilSaude1.getMes()+"/"+perfilSaude1.getAno());
        System.out.println(" Sua Idade é: " +perfilSaude1.birthDate()+" anos");
        System.out.println(" Sua Altura em Metros: " +perfilSaude1.getAltura()+" metros");
        System.out.println(" Seu Peso em Kilos: " +perfilSaude1.getPeso()+" KG");
        System.out.println(" Seu IMC: " + perfilSaude1.GetImc());
        System.out.println("******************************");
        
    }
    
}
