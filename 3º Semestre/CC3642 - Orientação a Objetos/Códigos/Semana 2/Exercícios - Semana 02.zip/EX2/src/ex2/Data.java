package ex2;
public class Data {
    private int mes, dia, ano;

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        if(mes > 12 )
            this.mes = 12;
        else if (mes < 1)
            this.mes = 1;
        else
            this.mes = mes;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        if(dia > 31)
            this.dia = 31;
        else if (dia < 1)
            this.dia = 1;
        else
            this.dia = dia;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        if( ano <= 0)
            this.ano = 2021;
        else
            this.ano = ano;
    }
    
    public void exibeData(){
        System.out.println("Data Digitada: "+dia+"/"+mes+"/"+ano);
    }

    @Override
    public String toString() {
        return "Data{" + "mes=" + mes + ", dia=" + dia + ", ano=" + ano + '}';
    }
    
}
