package ex2;
import java.util.Scanner;

public class EX2 {
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       int dia, mes, ano;
       
       Data data = new Data();
       
        System.out.println("Digite o Dia desejado: ");
        data.setDia(Integer.parseInt(input.nextLine()));
        System.out.println(" ");
        
        System.out.println("Digite o Mês desejado: ");
        data.setMes(Integer.parseInt(input.nextLine()));
        System.out.println(" ");
        
        System.out.println("Digite o Ano desejado: ");
        data.setAno(Integer.parseInt(input.nextLine()));
        System.out.println(" ");
        
        data.exibeData();
        System.out.println(" ");
    }
    
}
