package ex1;
import java.util.Scanner;

public class EX1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int volume, canal, op;
        Televisao tv1 = new Televisao();
        Televisao tv2 = new Televisao();
        
        System.out.println("********** TV1 *********");
        System.out.println("Digite o Modelo da TV1: ");
        tv1.setModelo(input.nextLine());
        System.out.println("Digite o valor da TV: ");
        tv1.setPreco(Double.parseDouble(input.nextLine()));
        System.out.println("Digite o tamanho da TV: ");
        tv1.setTamanho(Double.parseDouble(input.nextLine()));
        System.out.println("Digite um canal: ");
        tv1.setCanal(Integer.parseInt(input.nextLine()));
        System.out.println("Digite o Volume desejado: ");
        tv1.setVolume(Integer.parseInt(input.nextLine()));
        System.out.println("Você ligou a TV1!!!");
        tv1.setLigada(true);
        System.out.println(" ");
        
        System.out.println(tv1);
        System.out.println(" ");
        
        System.out.println("Deseja trocar o canal da TV1? Sim = 1 / Não = 0");
        op = Integer.parseInt(input.nextLine());
        if (op == 1){
            System.out.println("Digite o novo canal:");
            tv1.setCanal(Integer.parseInt(input.nextLine()));
            System.out.println(" ");
            System.out.println("Canal Trocado!!!");
            System.out.println(" ");
            System.out.println(tv1);
        }
        else{
            System.out.println("O canal continua o mesmo!!!");
            System.out.println(" ");
            System.out.println(tv1);
        }
        
        System.out.println(" ");
        System.out.println("Deseja trocar o volume da TV1? Sim = 1 / Não = 0");
        op = Integer.parseInt(input.nextLine());
        if (op == 1){
            System.out.println("Digite o novo volume:");
            tv1.setVolume(Integer.parseInt(input.nextLine()));
            System.out.println(" ");
            System.out.println("Volume Trocado!!!");
            System.out.println(" ");
            System.out.println(tv1);
        }
        else{
            System.out.println("O volume continua o mesmo!!!");
            System.out.println(" ");
            System.out.println(tv1);
        }
        
        System.out.println(" ");
        System.out.println("********** TV2 *********");
        System.out.println("Digite o Modelo da TV2: ");
        tv2.setModelo(input.nextLine());
        System.out.println("Digite o valor da TV: ");
        tv2.setPreco(Double.parseDouble(input.nextLine()));
        System.out.println("Digite o tamanho da TV: ");
        tv2.setTamanho(Double.parseDouble(input.nextLine()));
        System.out.println("Digite um canal: ");
        tv2.setCanal(Integer.parseInt(input.nextLine()));
        System.out.println("Digite o Volume desejado: ");
        tv2.setVolume(Integer.parseInt(input.nextLine()));
        System.out.println("Você ligou a TV2!!!");
        tv2.setLigada(true);
        System.out.println(" ");
        
        System.out.println(tv2);
        System.out.println(" ");
        
        System.out.println("Deseja trocar o canal da TV2? Sim = 1 / Não = 0");
        op = Integer.parseInt(input.nextLine());
        if (op == 1){
            System.out.println("Digite o novo canal:");
            tv2.setCanal(Integer.parseInt(input.nextLine()));
            System.out.println(" ");
            System.out.println("Canal Trocado!!!");
            System.out.println(" ");
            System.out.println(tv2);
        }
        else{
            System.out.println("O canal continua o mesmo!!!");
            System.out.println(" ");
            System.out.println(tv2);
        }
        
        System.out.println(" ");
        System.out.println("Deseja trocar o volume da TV2? Sim = 1 / Não = 0");
        op = Integer.parseInt(input.nextLine());
        if (op == 1){
            System.out.println("Digite o novo volume:");
            tv2.setVolume(Integer.parseInt(input.nextLine()));
            System.out.println(" ");
            System.out.println("Volume Trocado!!!");
            System.out.println(" ");
            System.out.println(tv2);
        }
        else{
            System.out.println("O volume continua o mesmo!!!");
            System.out.println(" ");
            System.out.println(tv2);
        }
        
        System.out.println(" ");
        System.out.println("Deseja desligar a TV2? Sim = 1 / Não = 0");
        op = Integer.parseInt(input.nextLine());
        if (op == 1){
            System.out.println("Desligando TV2....");
            tv2.setLigada(false);
            System.out.println(" ");
            System.out.println("TV2 Desligada!!!");
            System.out.println(" ");
            System.out.println(tv2);
        }
        else{
            System.out.println("A TV continua Ligada!!!");
            System.out.println(" ");
            System.out.println(tv2);
        }
    }
}
