package ex1;
public class Televisao {
    private String modelo;
    private double preco, tamanho;
    private int volume, canal;
    private boolean ligada;

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        if(preco <= 0)
            this.preco = 32;
        else
            this.preco = preco;
    }

    public double getTamanho() {
        return tamanho;
    }

    public void setTamanho(double tamanho) {
        this.tamanho = tamanho;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        if(volume < 0 || volume > 60)
            this.volume = 30;
        else
            this.volume = volume;
    }

    public int getCanal() {
        return canal;
    }

    public void setCanal(int canal) {
        if (canal < 1 || canal > 200)
            this.canal = 1;
        else
            this.canal = canal;
    }

    public boolean isLigada() {
        return ligada;
    }

    public void setLigada(boolean ligada) {
        this.ligada = ligada;
    }
    
    public void alteraVolume(int volume){
        this.volume = this.volume + volume;
    }
    
    public void alteraCanal(boolean aumenta){
        if(aumenta == true)
            this.canal++;
        else
            this.canal--;
    }

    @Override
    public String toString() {
        return "Televisao{" + "Modelo desta TV = " + modelo + ", Preco desta TV = " + preco + ", Tamanho desta TV = " + tamanho + ", Volume Escolhido = " + volume + ", Canal Escolhido = " + canal + ", Ligada = " + ligada + '}';
    }
}
