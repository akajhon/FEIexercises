package ex3;
import java.util.Scanner;

public class EX3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        Funcionario Func1 = new Funcionario();
        Funcionario Func2 = new Funcionario();
        
        System.out.println("Digite o primeiro nome do Funcionário 1: ");
        Func1.setNome(input.nextLine());
        System.out.println("Digite o Sobrenome do Funcionário 1: ");
        Func1.setSobrenome(input.nextLine());
        System.out.println("Digite o salário recebido pelo funcionário 1: ");
        Func1.setSalario(Double.parseDouble(input.nextLine()));
        System.out.println(" ");
        
        System.out.println("Digite o primeiro nome do Funcionário 2: ");
        Func2.setNome(input.nextLine());
        System.out.println("Digite o Sobrenome do Funcionário 2: ");
        Func2.setSobrenome(input.nextLine());
        System.out.println("Digite o salário recebido pelo funcionário 1: ");
        Func2.setSalario(Double.parseDouble(input.nextLine()));
        System.out.println(" ");
        
        System.out.println("***** Funcionário 1 *****");
        System.out.println(" ");
        System.out.println("Nome do Funcionário: " + Func1.getNome());
        System.out.println("Sobrenome do Funcionário: " + Func1.getSobrenome());
        System.out.println("Salário Anual: R$" + Func1.salarioAnual());
        System.out.println("Salário após os 10% de aumento: R$" + Func1.retornaSalario());
        System.out.println(" ");
        
        System.out.println("***** Funcionário 2 *****");
        System.out.println(" ");
        System.out.println("Nome do Funcionário: " + Func2.getNome());
        System.out.println("Sobrenome do Funcionário: " + Func2.getSobrenome());
        System.out.println("Salário Anual: R$" + Func2.salarioAnual());
        System.out.println("Salário após os 10% de aumento: R$" + Func2.retornaSalario());
        System.out.println(" ");
        
    }
    
}
