package ex3;

public class Funcionario {
    private String nome, sobrenome;
    private double salario;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        if(salario < 0)
            this.salario = 0;
        else
            this.salario = salario;
    }
    
    public double salarioAnual(){
        double salario_anual;
        salario_anual = 12 * salario;
        return salario_anual;
    }
    
    public double retornaSalario(){
        double total, temp;
        total = salario * 12;
        temp = total*0.1;
        total = total + temp;
        return total;
    }
    
}
