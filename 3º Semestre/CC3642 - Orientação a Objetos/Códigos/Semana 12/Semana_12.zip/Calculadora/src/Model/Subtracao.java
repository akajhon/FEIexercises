package Model;

/**
 *
 * @author akajhon
 */
public class Subtracao extends OperacaoMatematica {
    @Override
    public double calcular(double x, double y){
        return x - y;
    }
}
