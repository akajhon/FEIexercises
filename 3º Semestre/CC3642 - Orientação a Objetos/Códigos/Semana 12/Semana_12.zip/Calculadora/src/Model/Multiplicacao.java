package Model;

public class Multiplicacao extends OperacaoMatematica {
    @Override
    public double calcular(double x, double y){
        return x * y;
    }
}
