package calculadora;
import View.Janela;

/**
 *
 * @author akajhon
 */
public class Calculadora {
    public static void main(String[] args) {
        Janela window = new Janela();
        window.setVisible(true);
    }
    
}
