package soma;

public class Soma {
    public static void main(String[] args) {
        Janela window = new Janela();
        window.setVisible(true);
    }
    
}
