package somamvc;

import View.Janela;

/**
 * Soma MVC
 * @author akajhon
 */
public class SomaMVC {

    public static void main(String[] args) {
        Janela window = new Janela();
        window.setVisible(true);
    }
    
}
