package Controller;
import Model.Soma;
import View.Janela;

/**
 * Controller
 * @author akajhon
 */
public class Controller {
    private Janela view;

    public Controller(Janela view) {
        this.view = view;
    }
    
    public void control(){
        double n1 = Double.parseDouble(view.getInput1().getText());
        double n2 = Double.parseDouble(view.getInput2().getText());
        Soma soma = new Soma();
        
        view.getResultado().setText(String.valueOf(soma.calculator(n1,n2)));
    }
    
    public void controlClear(){
        view.getInput1().setText(" ");
        view.getInput2().setText(" ");
        view.getResultado().setText(" ");
    }
}
