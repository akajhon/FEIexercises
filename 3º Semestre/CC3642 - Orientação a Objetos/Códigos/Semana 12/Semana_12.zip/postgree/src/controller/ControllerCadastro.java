package controller;
import dao.AlunoDAO;
import dao.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Aluno;
import view.CadastroForm;

public class ControllerCadastro {
    private CadastroForm view;

    public ControllerCadastro(CadastroForm view) {
        this.view = view;
    }
    
    public void salvarAluno(){
        String nome = inputNome.getText();
        String usuario = inputUsuario.getText();
        String senha = inputSenha.getText();
        
        Aluno aluno = new Aluno(nome, usuario, senha);
        
        Conexao conn = new Conexao();
        try {
            Connection connection = conn.getConnection();
            AlunoDAO dao = new AlunoDAO(connection);
            dao.inserir(aluno);
            JOptionPane.showMessageDialog(rootPane, "Usuário cadastrado com sucesso!",
                    "Cadastro", JOptionPane.INFORMATION_MESSAGE);
        }
        catch(SQLException e) { 
            JOptionPane.showMessageDialog(rootPane, "Falha no cadastro!",
                    "Erro", JOptionPane.ERROR_MESSAGE);
            System.err.println(e);
        }
    }
    
}
