package postgree;

import view.LoginForm;

public class Postgree {

    public static void main(String[] args) {
        LoginForm lf = new LoginForm();
        lf.setVisible(true);
    }
    
}