package Model;

/**
 *
 * @author akajhon
 */
public class Soma {
    public double calculator(double a, double b){
        return a + b;
    }
}
