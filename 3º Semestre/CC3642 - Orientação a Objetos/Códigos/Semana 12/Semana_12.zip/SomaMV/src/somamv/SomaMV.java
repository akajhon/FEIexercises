package somamv;

import View.Janela;

/**
 *
 * @author akajhon
 */
public class SomaMV {

    public static void main(String[] args) {
        Janela window = new Janela();
        window.setVisible(true);
    }
    
}
